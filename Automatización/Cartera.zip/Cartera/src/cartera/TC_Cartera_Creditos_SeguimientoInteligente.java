package cartera;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_SeguimientoInteligente {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/SeguimientoInteligente";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/SeguimientoInteligente.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraCreditosSeguimientoInteligente() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		System.out.println("Se ingresa a la p�g: "+baseUrl);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass()+" ");
		System.out.println("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span/a")).click();
		Thread.sleep(10000);
		boolean simbolo = isElementPresent(By.id("ADDDYNAMICFILTERS1"));
		if (simbolo == true) {
			System.out.println("Accede al men� Cr�ditos");
			logEjecucion.append("Accede al men� Cr�ditos ");
			getFoto(driver);
		} else {
			System.out.println("No accede al men� Cr�ditos");
		}
		driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
		logEjecucion.append("Opcion filtros ");
		System.out.println("Opcion filtros");
		getFoto(driver);
		Thread.sleep(90000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
		logEjecucion.append("Filtrar por tipo credito ");
		System.out.println("Filtrar por tipo credito");
		getFoto(driver);
		Thread.sleep(9000);
		new Select(driver.findElement(By.name("vSOLICITUDTIPOCREDITO1"))).selectByVisibleText("INTELIGENTE");
		logEjecucion.append("Opci�n Inteligente ");
		System.out.println("Opci�n Inteligente");
		getFoto(driver);
		Thread.sleep(90000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
		logEjecucion.append("Filtrar por estado pago ");
		System.out.println("Filtrar por estado pago");
		getFoto(driver);
		Thread.sleep(180000);
		new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("AL D�A");
		logEjecucion.append("Opci�n al dia ");
		System.out.println("Opci�n al dia");
		getFoto(driver);
		Thread.sleep(180000);
		boolean boton = isElementPresent(By.id("vINFOCLIENTE1_0002"));
		if (boton == true) {
			System.out.println("Apertura de ventana para registrar seguimiento");
			logEjecucion.append("Apertura de ventana para registrar seguimiento ");
			getFoto(driver);
		} else {
			System.out.println("ERROR");
			logEjecucion.append("Error ");
			getFoto(driver);
		}
		driver.findElement(By.id("vINFOCLIENTE1_0002")).click();
		logEjecucion.append("Se presiona boton informacion cliente ");
		System.out.println("Se presiona boton informacion cliente");
		getFoto(driver);
		Thread.sleep(20000);
		driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
		boolean registrarSeguimiento = isElementPresent(By.xpath("//*[@id=\"vIMGCLIENTE\"]"));
		if (registrarSeguimiento == true) {
			System.out.println("Se procede a registrar seguimiento");
			driver.findElement(By.id("REGISTRARSEGUIMIENTO")).click();
			logEjecucion.append("Se procede a registrar seguimiento ");
			getFoto(driver);
			Thread.sleep(10000);
			driver.switchTo().defaultContent();
		} else {
			System.out.println("Error al registrar seguimiento");
			logEjecucion.append("Error al registrar seguimiento ");
			getFoto(driver);
		}
		driver.switchTo().frame(driver.findElement(By.id("gxp1_ifrm")));
		new Select(driver.findElement(By.id("vTIPOGESTIONID"))).selectByVisibleText("Administrativa");
		logEjecucion.append("Seleccionar opcion administrativa ");
		System.out.println("Seleccionar opcion administrativa");
		getFoto(driver);
		Thread.sleep(1000);
		new Select(driver.findElement(By.id("vTIPOCONTACTOID"))).selectByVisibleText("Administrativo");
		logEjecucion.append("Seleccionar opcion administrativo ");
		System.out.println("Seleccionar opcion administrativa");
		getFoto(driver);
		Thread.sleep(1000);
		new Select(driver.findElement(By.id("vCAUSALNOPAGOID"))).selectByVisibleText("Gestion Administrativa");
		logEjecucion.append("Seleccionar opcion Gestion Administrativa ");
		System.out.println("Seleccionar opcion Gestion Administrativa");
		getFoto(driver);
		Thread.sleep(1000);
		new Select(driver.findElement(By.id("vESTADOSEGUIMIENTOID"))).selectByVisibleText("Bienvenida Cliente");
		logEjecucion.append("Seleccionar opcion Bienvenida Cliente ");
		System.out.println("Seleccionar opcion Bienvenida Cliente");
		getFoto(driver);
		Thread.sleep(1000);
		SimpleDateFormat dia = new SimpleDateFormat("dd");
		SimpleDateFormat mes = new SimpleDateFormat("MM");
		SimpleDateFormat anno = new SimpleDateFormat("yy");
		String diaActual = dia.format(new Date());
		String mesActual = mes.format(new Date());
		String annoActual = anno.format(new Date());
		int diaHoy = Integer.parseInt(diaActual);
		int mesHoy = Integer.parseInt(mesActual);
		int annoHoy = Integer.parseInt(annoActual);
		System.out.println("Se ingresa fecha: " +diaHoy+"/"+mesHoy+"/"+annoHoy);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('vSEGCREDITOPROXIMAFECHA').value="+diaHoy+"+'/'+"+mesActual+"+'/'+"+annoActual+";");
		logEjecucion.append("Se ingresa fecha: " +diaHoy+"/"+mesHoy+"/"+annoHoy+" ");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("vSEGCREDITOCOMENTARIO")).sendKeys("Prueba de registrar seguimiento");
		logEjecucion.append("Se ingresa comentario ");
		System.out.println("Se ingresa comentario ");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		logEjecucion.append("Confirmar ");
		System.out.println("Confirmar");
		getFoto(driver);
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		try {
			assertEquals(driver.getTitle(), "Cr�ditos");
			System.out.println("Registro de seguimiento de manera exitosa");
			logEjecucion.append("Registro de seguimiento de manera exitosa ");
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}