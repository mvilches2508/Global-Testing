package cartera;

public class TC_Cartera_Creditos_SeguimientoInteligente {

}
