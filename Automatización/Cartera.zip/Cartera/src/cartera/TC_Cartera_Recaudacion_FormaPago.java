package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Recaudacion_FormaPago {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/RecaudacionFormaP";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/RecaudacionFormaP.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraRecaudacionFormaPago() throws Exception {
		try {
		Robot robot = new Robot();
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[3]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(5000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		logEjecucion.append("Acceso al men� Recaudacion, se filtran registro por estado");
		getFoto(driver);
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vRECAUDACIONESTADO1"))).selectByVisibleText("INGRESADA");
		logEjecucion.append("Opcion seleccionada: ingresada");
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.id("vVERCOMPROBANTE_0001")).click();
		logEjecucion.append("Seleccionar comprobante");
		getFoto(driver);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		driver.findElement(By.id("vRETOMARPASO2_0001")).click();
		logEjecucion.append("Retomar paso 2");
		getFoto(driver);
		Thread.sleep(5000);
		boolean pdf = isElementPresent(By.id("TEXTBLOCKTITLE"));
		if (pdf == true) {
			Thread.sleep(1000);
			driver.findElement(By.id("BTNSIGUIENTE")).click();
			logEjecucion.append("Presionar boton siguiente");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("BTNCONFIRMAR")).click();
			logEjecucion.append("Presionar boton confirmar");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("DVELOP_CONFIRMPANEL_BTNCONFIRMARContainer_SaveButton")).click();
			logEjecucion.append("Confirmar accion");
			getFoto(driver);
			Thread.sleep(5000);
			try {
				assertEquals(driver.findElement(By.xpath("//span/div")).getText(),
						"El monto ingresado por medios de pago debe ser igual al monto a abonar.");
				System.out.println("Verificaci�n exitosa, sistema no termina proceso debido a que no se ha agregado forma de pago");
				logEjecucion.append("Verificaci�n exitosa, sistema no termina proceso debido a que no se ha agregado forma de pago");
				getFoto(driver);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append(verificationErrors.append(e.toString()));
			}
		}
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}