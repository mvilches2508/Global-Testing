package cartera;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_ProcesosFForzar_Convencional {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PFAlzamientoConvencional";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PFAlzamientoConvencional.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTC_Cartera_ProcesosFForzar_Convencional() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[12]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[13]/a[3]")).click();
			logEjecucion.append("Ingreso al m�dulo Procesos, subm�dulo Forzar Alzamiento ");
			System.out.println("Ingreso al m�dulo Procesos, subm�dulo Forzar Alzamiento");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("vCRENROOPE")).clear();
			driver.findElement(By.id("vCRENROOPE")).sendKeys("180261185");
			logEjecucion.append("Se ingresa nro OP 180261185 ");
			System.out.println("Se ingresa nro OP 180261185");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vEMPRESA"))).selectByVisibleText("Prenda Chile");
			logEjecucion.append("Empresa seleccionada: Prenda Chile ");
			System.out.println("Empresa seleccionada: Prenda Chile");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNCONFIRMAR")).click();
			logEjecucion.append("Procesar ");
			System.out.println("Procesar");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("DVELOP_CONFIRMPANEL_BTNCONFIRMARContainer_SaveButton")).click();
			logEjecucion.append("Aceptar ");
			System.out.println("Aceptar");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("DVELOP_BOOTSTRAP_CONFIRMPANEL1Container_SaveButton")).click();
			logEjecucion.append("Continuar ");
			System.out.println("Continuar");
			getFoto(driver);
			Thread.sleep(60000);
			try {
				assertEquals(driver.findElement(By.id("PROCESOTITLE")).getText(), "Proceso");
				logEjecucion.append("Mensaje encontrado: "+driver.findElement(By.id("PROCESOTITLE")).getText()+" ");
				System.out.println("Mensaje encontrado: "+driver.findElement(By.id("PROCESOTITLE")).getText());
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append("Mensaje no encontrado: "+verificationErrors.append(e.toString())+" ");
				System.out.println("Mensaje no encontrado: "+verificationErrors.append(e.toString()));
				getFoto(driver);
				Thread.sleep(1000);
			}
			String nroOP = driver.findElement(By.xpath("//td[12]/span/a")).getText();
			if(nroOP=="180261185") {
				System.out.println(nroOP);
				logEjecucion.append("Alzamiento forzado realizado de manera exitosa ");
				System.out.println("Alzamiento forzado realizado de manera exitosa");
				getFoto(driver);
				Thread.sleep(1000);
			} else {
				System.out.println(nroOP);
				logEjecucion.append("Alzamiento forzado no realizado ");
				System.out.println("Alzamiento forzado no realizado");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}