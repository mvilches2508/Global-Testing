package cartera;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Principal {

	public static void main(String[] args) {
		SimpleDateFormat dia = new SimpleDateFormat("dd");
		SimpleDateFormat mes = new SimpleDateFormat("MM");
		SimpleDateFormat anno = new SimpleDateFormat("yy");
		String diaActual = dia.format(new Date()).valueOf(25);
		String mesActual = mes.format(new Date());
		String annoActual = anno.format(new Date());
		int diaHoy = Integer.parseInt(diaActual);
		int mesHoy = Integer.parseInt(mesActual);
		int annoHoy = Integer.parseInt(annoActual);
		System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
	}
}
