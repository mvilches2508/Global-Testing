package cartera;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Principal {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat dia = new SimpleDateFormat("dd");
		SimpleDateFormat mes = new SimpleDateFormat("MM");
		SimpleDateFormat anno = new SimpleDateFormat("yy");
		String diaActual = dia.format(new Date());
		String mesActual = mes.format(new Date());
		String annoActual = anno.format(new Date());
		int diaHoy = Integer.parseInt(diaActual);
		int mesHoy = Integer.parseInt(mesActual);
		int annoHoy = Integer.parseInt(annoActual);
		System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
		Calendar c = Calendar.getInstance();
		System.out.println(c.get(Calendar.DAY_OF_WEEK));
		
	}
}