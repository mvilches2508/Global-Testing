package cartera;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Principal {

	private String op;

	public Principal() {
	}

	public Principal(String op) {
		this.op = op;
	}

	public String getOp() {
		return op;
	}

	public static void setOp(String op) {
	}

	public static void main(String[] args) {
		String query;
		ConexionSQL conexion = ConexionSQL.getInstancia();
		Statement sentencia = null;
		PreparedStatement prpSentencia = null;
		ResultSet rs = null;
		try {
			query = ("Select * From creditos");
			sentencia = conexion.getConexion().createStatement();
			rs = sentencia.executeQuery(query);
			while (rs.next()) {
				setOp(rs.getString("id"));
			}
			rs.close();
			sentencia.close();
		} catch (SQLException ex) {
			System.out.println("Fallo en BD: " + ex);
		}
	}
}