package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Pagares_TrasladoEliminarCartaGuia {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/TrasladoEliminar";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/TrasladoEliminar.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1200x1200");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTCCarteraPagaresTrasladoEliminarCartaGuia() throws Exception {
		try {
			credenciales.generar();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass()+" ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass()+" ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//tr[8]/td/table/tbody/tr/td[2]/p/span/a")).click();
			logEjecucion.append("Acceso al men� Pagares ");
			System.out.println("Acceso al men� Pagares");
			getFoto(driver);
			Thread.sleep(10000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Guia Tipo");
			logEjecucion.append("Filtrar registro por guia tipo ");
			System.out.println("Filtrar registro por guia tipo");
			getFoto(driver);
			Thread.sleep(20000);
			new Select(driver.findElement(By.id("vCARTAGUIATIPO1"))).selectByVisibleText("TRASLADO");
			logEjecucion.append("Opcion traslado ");
			System.out.println("Opcion traslado");
			getFoto(driver);
			Thread.sleep(20000);
			driver.findElement(By.id("vDELETE_0001")).click();
			logEjecucion.append("Se procede a eliminar registro ");
			System.out.println("Se procede a eliminar registro");
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.name("BTN_TRN_ENTER")).click();
			logEjecucion.append("Confirmar ");
			System.out.println("Confirmar");
			getFoto(driver);
			Thread.sleep(10000);
			getFoto(driver);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		}	catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}