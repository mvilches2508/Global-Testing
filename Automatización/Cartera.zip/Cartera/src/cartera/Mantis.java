package cartera;

import biz.futureware.mantis.rpc.soap.client.IssueData;
import biz.futureware.mantis.rpc.soap.client.MantisConnectLocator;
import biz.futureware.mantis.rpc.soap.client.MantisConnectPortType;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.rmi.RemoteException;
import javax.xml.rpc.ServiceException;

public class Mantis {

	public void creaIssue(String rutaEvidencia, String log, String nombreClase) throws ServiceException, MalformedURLException, RemoteException, IOException {
		MantisConnectLocator mcl = new MantisConnectLocator();
		MantisConnectPortType mcp = mcl.getMantisConnectPort(new URL("http://54.235.81.157:81/mantis/api/soap/mantisconnect.php"));
		int id = 209;
		IssueData issue = mcp.mc_issue_get("administrator", "q4_1n0v4b1z", BigInteger.valueOf(id));
		System.out.println("stado:" + issue.toString());
		IssueData defecto = mcp.mc_issue_get("administrator", "q4_1n0v4b1z", BigInteger.valueOf(209));
		System.out.println("defecto " + defecto.getSummary());
		defecto.setDescription(log);
		defecto.setSummary("Defecto autom�tico: "+nombreClase);
		BigInteger defectoAuto = mcp.mc_issue_add("administrator", "q4_1n0v4b1z", defecto);
		System.out.println(rutaEvidencia);
		byte[] fileContent = Files.readAllBytes(new File(rutaEvidencia).toPath());
		mcp.mc_issue_attachment_add("administrator", "q4_1n0v4b1z", defectoAuto, "TEST-QA" + id+".zip", "zip", fileContent);
	}
}
