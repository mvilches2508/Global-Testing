package cartera;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.openqa.selenium.*;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_GenerarPrepago_Credito {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
				"src/cartera/driver/phantomjs.exe");
		driver = new PhantomJSDriver(capabilities);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraGenerarPrepagoCredito() throws Exception {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[7]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.findElement(By.id("TEXTBLOCKTITLE")).getText(), "Generar Prepago");
			System.out.println("Acceso al men�: " + driver.findElement(By.id("TEXTBLOCKTITLE")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		new Select(driver.findElement(By.id("vTIPODEPREPAGO"))).selectByVisibleText("Prepago");
		Thread.sleep(1000);
		new Select(driver.findElement(By.id("vCREREFINANCIA"))).selectByVisibleText("Si");
		Thread.sleep(1000);
		new Select(driver.findElement(By.id("vRECAUDACIONDESCJUDICIALES"))).selectByVisibleText("10%");
		Thread.sleep(1000);
		SimpleDateFormat dia = new SimpleDateFormat("dd");
		SimpleDateFormat mes = new SimpleDateFormat("MM");
		SimpleDateFormat anno = new SimpleDateFormat("yy");
		String diaActual = dia.format(new Date());
		String mesActual = mes.format(new Date());
		String annoActual = anno.format(new Date());
		int diaHoy = Integer.parseInt(diaActual);
		int mesHoy = Integer.parseInt(mesActual);
		int annoHoy = Integer.parseInt(annoActual);
		System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('vCREFCHPREPAGO').value=" + diaHoy + "+'/'+" + mesActual + "+'/'+"
				+ annoActual + ";");
		Thread.sleep(1000);
		driver.findElement(By.id("vAUXCRENROOPE")).clear();
		driver.findElement(By.id("vAUXCRENROOPE")).sendKeys("180234548");
		System.out.println("N�mero de OP ingresada: 180234548");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.findElement(By.xpath("//span/div")).getText(),
					"No es posible generar el prepago : El cr�dito debe estar Contabilizado.");
			System.out.println(driver.findElement(By.xpath("//span/div")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}