package cartera;

import org.testng.Assert;
import org.testng.annotations.*;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_ProcesosFPrendasAfianza {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PFPrendasAfianza";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PFPrendasAfianza.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void testTC_Cartera_ProcesosFPrendasAfianza() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(20000);
			driver.findElement(By.xpath("//li[12]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[13]/a[8]")).click();
			logEjecucion.append("Ingreso al m�dulo Procesos Financieros, subm�dulo Prendas AFIANZA ");
			System.out.println("Ingreso al m�dulo Procesos Financieros, subm�dulo Prendas AFIANZA");
			getFoto(driver);
			Thread.sleep(5000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado Proceso");
			logEjecucion.append("Filtrar por estado proceso ");
			System.out.println("Filtrar por estado proceso");
			getFoto(driver);
			Thread.sleep(20000);
			new Select(driver.findElement(By.id("vPROCESOESTADO1"))).selectByVisibleText("Terminado");
			logEjecucion.append("Estado proceso: Terminado ");
			System.out.println("Estado proceso: Terminado");
			getFoto(driver);
			Thread.sleep(20000);
			driver.findElement(By.id("vBTNWORKFLOW_0012")).click();
			logEjecucion.append("Seleccionar registro ");
			System.out.println("Seleccionar registro");
			getFoto(driver);
			Thread.sleep(10000);
			driver.switchTo().frame("gxp0_ifrm");
			boolean mensajeError = isElementPresent(By.xpath("//span/div"));
			if (mensajeError == true) {
				assertTrue(isElementPresent(By.xpath("//span/div")));
				logEjecucion.append("Error al consultar workflow ");
				System.out.println("Error al consultar workflow");
				getFoto(driver);
				Thread.sleep(1000);
				AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
				zip.comprimir();
				Thread.sleep(5000);
				mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
				Assert.fail();
			} else {
				logEjecucion.append("Consulta de workflow realizado correctamente ");
				System.out.println("Consulta de workflow realizado correctamente");
				getFoto(driver);
				Thread.sleep(1000);
				driver.switchTo().defaultContent();
				Thread.sleep(1000);
				driver.findElement(By.id("gxp0_cls")).click();
				getFoto(driver);
				Thread.sleep(3000);
				driver.findElement(By.id("vGETDOCUMENTOS_0014")).click();
				logEjecucion.append("Seleccionar registro ");
				System.out.println("Seleccionar registro");
				getFoto(driver);
				Thread.sleep(10000);
				driver.switchTo().frame("gxp0_ifrm");
				boolean mensajeErrorDoc = isElementPresent(By.xpath("//span/div"));
				if (mensajeErrorDoc == true) {
					assertTrue(isElementPresent(By.xpath("//span/div")));
					logEjecucion.append("Error al consultar documentos ");
					System.out.println("Error al consultar documentos");
					getFoto(driver);
					Thread.sleep(1000);
					AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
					zip.comprimir();
					Thread.sleep(5000);
					mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
					Assert.fail();
				} else {
					logEjecucion.append("Consulta de documentos realizado correctamente ");
					System.out.println("Consulta de documentos realizado correctamente");
					getFoto(driver);
					Thread.sleep(1000);
					driver.switchTo().defaultContent();
					Thread.sleep(1000);
					driver.findElement(By.id("gxp0_cls")).click();
					Thread.sleep(3000);
					getFoto(driver);
					driver.findElement(By.id("EXPORT")).click();
					logEjecucion.append("Descargar archivo ");
					System.out.println("Descargar archivo");
					getFoto(driver);
					Thread.sleep(30000);
				}
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}