package cartera;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TC_Cartera_PACGenerarNomina_Fecha {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/GNFecha";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/GNFecha.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void testTCCarteraPACGenerarNominaFecha() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());			
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[6]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[7]/a[2]")).click();
			logEjecucion.append("Ingreso al m�dulo PAC,sub m�dulo Generar N�mina de Cargo ");
			System.out.println("Ingreso al m�dulo PAC,sub m�dulo Generar N�mina de Cargo");
			getFoto(driver);
			Thread.sleep(4000);
			SimpleDateFormat dia = new SimpleDateFormat("dd");
			SimpleDateFormat mes = new SimpleDateFormat("MM");
			SimpleDateFormat anno = new SimpleDateFormat("yy");
			String diaActual = dia.format(new Date()).valueOf(25);
			String mesActual = mes.format(new Date());
			String annoActual = anno.format(new Date());
			int diaHoy = Integer.parseInt(diaActual);
			int mesHoy = Integer.parseInt(mesActual);
			int annoHoy = Integer.parseInt(annoActual);
			System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vFECHA').value=" + diaHoy + "+'/'+" + mesActual + "+'/'+"+ annoActual + ";");
			logEjecucion.append("Se ingresa fecha: "+ diaHoy + "/" + mesHoy + "/" + annoHoy+" ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}