package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_InteligenteMoroso {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "D:/Cartera/bin/cartera/evidencia/InteligenteMoroso";
	private static final String EVIDENCIAZIP = "D:/Cartera/bin/cartera/evidencia/InteligenteMoroso.zip";
	private StringBuilder logEjecucion = new StringBuilder();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
				"bin/cartera/driver/phantomjs.exe");
		driver = new PhantomJSDriver(capabilities);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraCreditosInteligenteMoroso() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span/a")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Cr�ditos");
			System.out.println("Accede al men� Cr�ditos");
			logEjecucion.append("Accede al men� Cr�ditos");
			getFoto(driver);
			Thread.sleep(1000);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
		logEjecucion.append("Opciones de filtro");
		getFoto(driver);
		Thread.sleep(20000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
		logEjecucion.append("Filtro tipo cr�dito");
		getFoto(driver);
		Thread.sleep(15000);
		new Select(driver.findElement(By.name("vSOLICITUDTIPOCREDITO1"))).selectByVisibleText("INTELIGENTE");
		logEjecucion.append("Opcion inteligente");
		getFoto(driver);
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
		logEjecucion.append("Filtro estado pago");
		getFoto(driver);
		Thread.sleep(15000);
		new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("MOROSO");
		logEjecucion.append("Opcion moroso");
		getFoto(driver);
		Thread.sleep(10000);
		String op = driver.findElement(By.xpath("//tr[5]/td[3]/span/a")).getText();
		System.out.println("Nro de OP seleccionada: "+op);
		driver.findElement(By.id("vEDITARCONVENIDO_0005")).click();
		logEjecucion.append("Editar");
		getFoto(driver);
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Editar Convenido");
			System.out.println("Ingreso a formulario: "+driver.getTitle());
			logEjecucion.append("Ingreso a formulario: "+driver.getTitle());
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0001")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0001")).sendKeys("301218");
		logEjecucion.append("Ingresar monto cuotra 301218");
		getFoto(driver);
		Thread.sleep(1000);
		String estado1 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0001")).getText();
		System.out.println(estado1);
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).sendKeys("311218");
		logEjecucion.append("Ingresar monto cuotra 311218");
		getFoto(driver);
		Thread.sleep(1000);
		String estado2 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		System.out.println(estado2);
		driver.findElement(By.id("BTNCONFIRMAR")).click();
		logEjecucion.append("Confirmar");
		getFoto(driver);
		Thread.sleep(20000);
		driver.findElement(By.id("vEDITARCONVENIDO_0004")).click();
		logEjecucion.append("Seleccionar registro");
		getFoto(driver);
		Thread.sleep(10000);
		String estado3 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0001")).getText();
		System.out.println(estado3);
		String estado4 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		System.out.println(estado4);
		if(estado1!=estado3 && estado2!=estado4) {
			System.out.println("Estado de cuota actualizado correctamente");
			logEjecucion.append("Estado de cuota actualizado correctamente");
			getFoto(driver);
		}else {
			System.out.println("Error, estado de cuota no fue actualizada");
			logEjecucion.append("Error, estado de cuota no fue actualizada");
			getFoto(driver);
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (NoSuchElementException e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}