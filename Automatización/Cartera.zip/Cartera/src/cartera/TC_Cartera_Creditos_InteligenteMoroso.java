package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.openqa.selenium.*;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_InteligenteMoroso {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
				"src/cartera/driver/phantomjs.exe");
		driver = new PhantomJSDriver(capabilities);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraCreditosInteligenteMoroso() throws Exception {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span/a")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Cr�ditos");
			System.out.println("Accede al men� Cr�ditos");
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
		Thread.sleep(20000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
		Thread.sleep(15000);
		new Select(driver.findElement(By.name("vSOLICITUDTIPOCREDITO1"))).selectByVisibleText("INTELIGENTE");
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
		Thread.sleep(15000);
		new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("MOROSO");
		Thread.sleep(10000);
		String op = driver.findElement(By.xpath("//tr[5]/td[3]/span/a")).getText();
		System.out.println(op);
		driver.findElement(By.id("vEDITARCONVENIDO_0005")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Editar Convenido");
			System.out.println("Ingreso a formulario: "+driver.getTitle());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0001")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0001")).sendKeys("301218");
		Thread.sleep(1000);
		String estado1 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0001")).getText();
		System.out.println(estado1);
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).sendKeys("311218");
		Thread.sleep(1000);
		String estado2 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		System.out.println(estado2);
		driver.findElement(By.id("BTNCONFIRMAR")).click();
		Thread.sleep(20000);
		driver.findElement(By.id("vEDITARCONVENIDO_0004")).click();
		Thread.sleep(10000);
		String estado3 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0001")).getText();
		System.out.println(estado3);
		String estado4 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		System.out.println(estado4);
		if(estado1!=estado3 && estado2!=estado4) {
			System.out.println("Estado de cuota actualizado correctamente");
		}else {
			System.out.println("Error, estado de cuota no fue actualizada");
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}