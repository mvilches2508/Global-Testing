package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_LeasingPreJudicial {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/LeasingPreJudicial";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/LeasingPreJudicial.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraCreditosLeasingPreJudicial() throws Exception {
		try {
			driver.get(baseUrl);
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
			System.out.println("Se ingresa a la p�g: "+baseUrl);
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass()+" ");
			System.out.println("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//span/a")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
			logEjecucion.append("Acceso al men� Creditos, se procede a filtrar registros ");
			System.out.println("Acceso al men� Creditos, se procede a filtrar registros");
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
			logEjecucion.append("Se procede a filtrar registros por tipo cr�dito ");
			System.out.println("Se procede a filtrar registros por tipo cr�dito");
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vSOLICITUDTIPOCREDITO1"))).selectByVisibleText("LEASING");
			logEjecucion.append("Seleccionar opcion leasing ");
			System.out.println("Seleccionar opcion leasing");
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
			logEjecucion.append("Se procede a filtrar registros por estado pago");
			System.out.println("Se procede a filtrar registros por estado pago");
			getFoto(driver);
			Thread.sleep(180000);
			new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("PRE JUDICIAL");
			logEjecucion.append("Seleccionar opcion preJudicial");
			System.out.println("Seleccionar opcion preJudicial");
			getFoto(driver);
			Thread.sleep(180000);
			driver.findElement(By.id("vEDITARCONVENIDO_0001")).click();
			logEjecucion.append("Seleccionar registro para ser editado ");
			System.out.println("Seleccionar registro para ser editado");
			getFoto(driver);
			Thread.sleep(10000);
			String op = driver.findElement(By.id("span_vCRENROOPE")).getText();
			System.out.println("Nro de OP seleccionada: "+op);
			logEjecucion.append("Nro de OP seleccionada: "+op+" ");
			String monto1 = driver.findElement(By.id("span_SDTCONVENIDO__DETCRETOTALSALDOS_0001")).getText();
			driver.findElement(By.id("SDTCONVENIDO__DETCRECUO_0001")).clear();
			driver.findElement(By.id("SDTCONVENIDO__DETCRECUO_0001")).sendKeys("1290899");
			logEjecucion.append("Editar monto cuota 1 ");
			System.out.println("Editar monto cuota 1");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("SDTCONVENIDO__DETCREPAGTOT_0001")).clear();
			driver.findElement(By.id("SDTCONVENIDO__DETCREPAGTOT_0001")).sendKeys("1290899");
			logEjecucion.append("Editar monto cuota 2 ");
			System.out.println("Editar monto cuota 2");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNCONFIRMAR")).click();
			logEjecucion.append("Confirmar edicion de credito: "+op+" ");
			System.out.println("Confirmar edicion de credito: "+op);
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.id("vEDITARCONVENIDO_0001")).click();
			logEjecucion.append("Verificar edicion del credito: "+op+" ");
			System.out.println("Verificar edicion del credito: "+op);
			getFoto(driver);
			Thread.sleep(10000);
			String monto2 = driver.findElement(By.id("span_SDTCONVENIDO__DETCRETOTALSALDOS_0001")).getText();
			if(monto1==monto2) {
				System.out.println("Error al actualizar monto de cuota a pagar");
				logEjecucion.append("Error al actualizar monto de cuota a pagar ");
				getFoto(driver);
				Thread.sleep(1000);
			} else {
				System.out.println("Monto de cuota a pagar actualizado correctamente");
				logEjecucion.append("Monto de cuota a pagar actualizado correctamente ");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}