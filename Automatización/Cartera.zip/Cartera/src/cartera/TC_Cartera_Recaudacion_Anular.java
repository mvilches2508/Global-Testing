package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Recaudacion_Anular {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/RecaudacionAnular";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/RecaudacionAnular.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "https://www.gemma.cl/cartera2019/seclogin.aspx";
	}

	@Test
	public void testTCCarteraRecaudacionAnular() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		System.out.println("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass()+" ");
		System.out.println("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass()+" ");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[3]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(5000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		logEjecucion.append("Acceso al menu Recaudacion, filtrando registro por estado ");
		System.out.println("Acceso al menu Recaudacion, filtrando registro por estado ");
		getFoto(driver);
		Thread.sleep(20000);
		new Select(driver.findElement(By.id("vRECAUDACIONESTADO1"))).selectByVisibleText("INGRESADA PREPAGO");
		logEjecucion.append("Opcion seleccionada Ingresada prepago ");
		System.out.println("Opcion seleccionada Ingresada prepago ");
		getFoto(driver);
		Thread.sleep(20000);
		driver.findElement(By.id("vDELETE_0001")).click();
		Thread.sleep(5000);
		try {
			assertEquals(driver.findElement(By.xpath("//span/span")).getText(), "Confirme la eliminaci�n de los datos.");
			System.out.println("Se procede a eliminar registro "+driver.findElement(By.xpath("//span/span")).getText());
			logEjecucion.append("Se procede a eliminar registro ");
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		Thread.sleep(1000);
		driver.findElement(By.id("BTN_TRN_ENTER")).click();
		logEjecucion.append("Presionar boton continuar ");
		System.out.println("Presionar boton continuar ");
		getFoto(driver);
		Thread.sleep(10000);
		boolean eliminacion = isElementPresent(By.id("RECAUDACIONTITLE"));
		if(eliminacion==true) {
			System.out.println("Registro eliminado satisfactoriamente");
			logEjecucion.append("Registro eliminado satisfactoriamente ");
			getFoto(driver);
		}else {
			System.out.println("Error al eliminar registro");
			logEjecucion.append("Error al eliminar registro ");
			getFoto(driver);
		}
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	} catch (Exception e) {
		logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		Thread.sleep(5000);
		mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
		throw(e);
	}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}