package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Cheques_VolverDepositado {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "D:/Cartera/bin/cartera/evidencia/VolverDepositado";
	private static final String EVIDENCIAZIP = "D:/Cartera/bin/cartera/evidencia/VolverDepositado.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraChequesVolverDepositado() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[6]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		logEjecucion.append("Acceso al men� cheque");
		getFoto(driver);
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCHEQUEESTADO1"))).selectByVisibleText("COBRADO");
		logEjecucion.append("Seleccionar cheque en estado cobrado");
		getFoto(driver);
		Thread.sleep(10000);
		String procesarCheque = driver.findElement(By.xpath("//tr[2]/td[8]/span/a")).getText();
		System.out.println("Nro de cheque a procesar: "+procesarCheque);
		driver.findElement(By.id("vCAMBIARESTADOADEPOSITADO_0002")).click();
		logEjecucion.append("Cambiar estado");
		getFoto(driver);
		Thread.sleep(10000);
		boolean depositarCheque = isElementPresent(By.xpath("//td"));
		if (depositarCheque == true) {
			Date fecha = new Date();
			DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy");
			driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
			driver.findElement(By.id("vCHEQUEFECHADEPOSITO")).clear();
			driver.findElement(By.id("vCHEQUEFECHADEPOSITO")).sendKeys(formatoFecha.format(fecha));
			System.out.println("Fecha ingresada: "+formatoFecha.format(fecha));
			logEjecucion.append("Fecha ingresada: "+formatoFecha.format(fecha));
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vCHEQUENROCOMPROBANTE")).clear();
			driver.findElement(By.id("vCHEQUENROCOMPROBANTE")).sendKeys("01020340");
			logEjecucion.append("Nro de comprobante ingresado: 01020340");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
		} else {
			System.out.println("Error a volver depositar cheque");
			logEjecucion.append("Error a volver depositar cheque");
			getFoto(driver);
		}
		getFoto(driver);
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("N� Cheque");
		logEjecucion.append("Seleccionar cheque");
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.id("vCHEQUENUMERO1")).clear();
		driver.findElement(By.id("vCHEQUENUMERO1")).sendKeys(procesarCheque);
		logEjecucion.append("Ingresar cheque: "+procesarCheque);
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("vCHEQUENUMERO1")).click();
		logEjecucion.append("Confirmar accion");
		getFoto(driver);
		Thread.sleep(1000);
		try {
			assertEquals(driver.findElement(By.id("span_CHEQUEESTADO_0001")).getText(), "DEPOSITADO");
			System.out.println("Cheque en estado cobrado es nuevamente depositado de manera exitosa");
			logEjecucion.append("Cheque en estado cobrado es nuevamente depositado de manera exitosa");
			getFoto(driver);
			Thread.sleep(1000);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	} catch (Exception e) {
		logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		Thread.sleep(5000);
		mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
		throw(e);
	}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}