package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Pagares_TrasladoAprobar {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "D:/Cartera/bin/cartera/evidencia/TrasladoAprobar";
	private static final String EVIDENCIAZIP = "D:/Cartera/bin/cartera/evidencia/TrasladoAprobar.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("headless");
        options.addArguments("window-size=1200x900");
        driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraPagaresTrasladoAprobar() throws Exception {
		try {
			driver.get(baseUrl);
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//tr[8]/td/table/tbody/tr/td[2]/p/span/a")).click();
			logEjecucion.append("Acceso al men� Pagares");
			System.out.println("Acceso al men� Pagares");
			getFoto(driver);
			Thread.sleep(10000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Guia Tipo");
			logEjecucion.append("Filtrar registro por guia tipo");
			System.out.println("Filtrar registro por guia tipo");
			getFoto(driver);
			Thread.sleep(20000);
			new Select(driver.findElement(By.id("vCARTAGUIATIPO1"))).selectByVisibleText("TRASLADO");
			logEjecucion.append("Opcion traslado");
			System.out.println("Opcion traslado");
			getFoto(driver);
			Thread.sleep(20000);
			String estado1 = driver.findElement(By.id("span_CARTAGUIAESTADO_0002")).getText();
			logEjecucion.append("Registro seleccionado: "+estado1);
			System.out.println("Registro seleccionado: "+estado1);
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vACEPTARCARTAGUIA_0002")).click();
			Thread.sleep(6000);
			String aceptar = driver.findElement(By.id("DVELOP_CONFIRMPANEL_ACEPTARCARTAGUIAContainer_ConfirmationText")).getText();
			logEjecucion.append(aceptar);
			System.out.println(aceptar);
			getFoto(driver);
			Thread.sleep(1000);
			try {
				assertTrue(driver.findElement(By.id("DVELOP_CONFIRMPANEL_ACEPTARCARTAGUIAContainer_ConfirmationText"))
						.getText().matches("^exact:� Desea Confirmar la aceptaci�n de �sta carta gu�a [\\s\\S]$"));
				logEjecucion.append("Confirmar");
				System.out.println("Confirmar");
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append(verificationErrors.append(e.toString()));
				System.out.println(verificationErrors.append(e.toString()));
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("DVELOP_CONFIRMPANEL_ACEPTARCARTAGUIAContainer_SaveButton")).click();
			logEjecucion.append("Procesar");
			System.out.println("Procesar");
			getFoto(driver);
			Thread.sleep(10000);
			String estado2 = driver.findElement(By.id("span_CARTAGUIAESTADO_0002")).getText();
			logEjecucion.append("Registro seleccionado: "+estado2);
			System.out.println("Registro seleccionado: "+estado2);
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (NoSuchElementException e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
		} catch (ElementNotVisibleException e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}