package cartera;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1_2_3 {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "D:/Cartera/bin/cartera/evidencia/NRPaso1-2-3";
	private static final String EVIDENCIAZIP = "D:/Cartera/bin/cartera/evidencia/NRPaso1-2-3.zip";
	private StringBuilder logEjecucion = new StringBuilder();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
				"bin/cartera/driver/phantomjs.exe");
		driver = new PhantomJSDriver(capabilities);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso123() throws Exception {
		try {
		Robot robot = new Robot();
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(20000);
		driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCREESTADOCONTRATO"))).selectByVisibleText("VIGENTE");
		logEjecucion.append("Seleccion de OP en estado Vigente");
		getFoto(driver);
		Thread.sleep(5000);
		driver.findElement(By.id("BTNBUSCAR")).click();
		logEjecucion.append("Buscar OP en estado Vigente");
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.id("vSELECCIONAR_0005")).click();
		logEjecucion.append("Seleccionar registro");
		getFoto(driver);
		Thread.sleep(10000);
		String op = driver.findElement(By.id("span_CRENROOPE_0005")).getText();
		System.out.println("N�mero de OP seleccionada: "+op);
		logEjecucion.append("N�mero de OP seleccionada: "+op);
		new Select(driver.findElement(By.id("vRECAUDACIONOTROSID"))).selectByVisibleText("Otros");
		logEjecucion.append("Recaudacion seleccionada: Otros");
		getFoto(driver);
		Thread.sleep(5000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0001")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0002")).click();
		logEjecucion.append("Seleccionar cuotas");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		logEjecucion.append("Presionar boton siguente");
		getFoto(driver);
		Thread.sleep(15000);
		driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
		boolean ingresarFecha = isElementPresent(By.id("vCREFCHPAGOREAL"));
		if (ingresarFecha == true) {
			SimpleDateFormat fecha = new SimpleDateFormat("ddMMyy");
			String fechaHoy = fecha.format(new Date());
			int dia = Integer.parseInt(fechaHoy);
			System.out.println("Fecha ingresada: "+dia);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vCREFCHPAGOREAL').value=" + dia + ";");
			logEjecucion.append("Fecha ingresada: "+dia);
			getFoto(driver);
		} else {
			System.out.println("Error al ingresar fecha");
			logEjecucion.append("Error al ingresar fecha");
			getFoto(driver);
		}
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		logEjecucion.append("Presionar boton continuar");
		getFoto(driver);
		driver.switchTo().defaultContent();
		Thread.sleep(20000);
		try {
			assertEquals(driver.findElement(By.id("TEXTBLOCKTITLE")).getText(), "Pagar Cuotas - Paso 2 de 3");
			String texto = driver.findElement(By.id("TEXTBLOCKTITLE")).getText();
			System.out.println("Paso 1 realizado de manera exitosa, t�tulo de p�gina actual: " + texto);
			logEjecucion.append("Paso 1 realizado de manera exitosa, t�tulo de p�gina actual: " + texto);
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		Thread.sleep(1000);
		String montoDesc1 = driver.findElement(By.xpath("//td/table/tbody/tr/td[6]/span")).getText();
		driver.findElement(By.id("MODIFDESCINTERESES")).click();
		logEjecucion.append("Modificar descuentp intereses");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("vRECAUDACIONDESCINTERESESMORA")).clear();
		driver.findElement(By.id("vRECAUDACIONDESCINTERESESMORA")).sendKeys("35,20%");
		logEjecucion.append("Modificar descuentp intereses: 35,20%");
		getFoto(driver);
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);
		driver.findElement(By.id("MODIFDESCGASTOS")).click();
		logEjecucion.append("Modificar descuentp gastos");
		getFoto(driver);
		Thread.sleep(1000);
		String montoDesc2 = driver.findElement(By.id("span_vRECAUDACIONINTERESESMORAFINAL")).getText();
		if (montoDesc1 != montoDesc2) {
			System.out.println("Porcentaje de descuento aplicado de manera exitosa");
			logEjecucion.append("Porcentaje de descuento aplicado de manera exitosa");
			getFoto(driver);
		} else {
			System.out.println("Error al aplicar descuento");
			logEjecucion.append("Porcentaje de descuento aplicado de manera exitosa");
			getFoto(driver);
		}
		Thread.sleep(1000);
		driver.findElement(By.id("vRECAUDACIONDESCGASTOSCOBRANZA")).clear();
		driver.findElement(By.id("vRECAUDACIONDESCGASTOSCOBRANZA")).sendKeys("7,4");
		logEjecucion.append("Gastos cobranza: 7,4");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("MODIFDESCINTERESES")).click();
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		logEjecucion.append("Presionar boton siguiente");
		getFoto(driver);
		Thread.sleep(10000);
		try {
			assertEquals(driver.findElement(By.id("TEXTBLOCKTITLE")).getText(), "Pagar Cuotas - Paso 3 de 3");
			String texto2 = driver.findElement(By.id("TEXTBLOCKTITLE")).getText();
			System.out.println("Paso 2 realizado de manera exitosa, t�tulo de p�gina actual: " + texto2);
			logEjecucion.append("Paso 2 realizado de manera exitosa, t�tulo de p�gina actual: " + texto2);
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		String totalAbonar = driver.findElement(By.xpath("//*[@id=\"span_vTOTALCONIVA\"]")).getText();
		new Select(driver.findElement(By.id("vFORMADEPAGOID"))).selectByVisibleText("Efectivo");
		logEjecucion.append("Seleccionar forma de pago efectivo");
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.id("vRECAUDACIONFORMADEPAGOMONTO")).clear();
		driver.findElement(By.id("vRECAUDACIONFORMADEPAGOMONTO")).sendKeys(totalAbonar);
		logEjecucion.append("Se ingresa monto a pagar: "+totalAbonar);
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("AGREGAR")).click();
		logEjecucion.append("Agregar forma de pago");
		getFoto(driver);
		Thread.sleep(6000);
		driver.findElement(By.id("BTNCONFIRMAR")).click();
		logEjecucion.append("Presionar boton confirmar");
		getFoto(driver);
		Thread.sleep(6000);
		boolean confirmarPagoCuotas = isElementPresent(By.xpath("//div/div/div/div[2]"));
		if (confirmarPagoCuotas == true) {
			driver.findElement(By.id("DVELOP_CONFIRMPANEL_BTNCONFIRMARContainer_SaveButton")).click();
			logEjecucion.append("Confirmar accion");
			getFoto(driver);
		} else {
			System.out.println("Error al confirmar pago de cuotas");
			logEjecucion.append("Error al confirmar pago de cuotas");
			getFoto(driver);
		}
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Recaudacion");
			System.out.println("Nueva recaudaci�n realizada de manera exitosa");
			logEjecucion.append("Nueva recaudaci�n realizada de manera exitosa");
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (NoSuchElementException e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}