package cartera;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1_2_3 {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso123() throws Exception {
		Robot robot = new Robot();
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(20000);
		driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCREESTADOCONTRATO"))).selectByVisibleText("VIGENTE");
		Thread.sleep(5000);
		driver.findElement(By.id("BTNBUSCAR")).click();
		Thread.sleep(10000);
		driver.findElement(By.id("vSELECCIONAR_0005")).click();
		Thread.sleep(10000);
		String op = driver.findElement(By.id("span_CRENROOPE_0005")).getText();
		System.out.println("N�mero de OP seleccionada: "+op);
		new Select(driver.findElement(By.id("vRECAUDACIONOTROSID"))).selectByVisibleText("Otros");
		Thread.sleep(5000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0001")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0002")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		Thread.sleep(15000);
		driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
		boolean ingresarFecha = isElementPresent(By.id("vCREFCHPAGOREAL"));
		if (ingresarFecha == true) {
			SimpleDateFormat fecha = new SimpleDateFormat("ddMMyy");
			String fechaHoy = fecha.format(new Date());
			int dia = Integer.parseInt(fechaHoy);
			System.out.println(dia);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vCREFCHPAGOREAL').value=" + dia + ";");
		} else {
			System.out.println("Error al ingresar fecha");
		}
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		driver.switchTo().defaultContent();
		Thread.sleep(20000);
		try {
			assertEquals(driver.findElement(By.id("TEXTBLOCKTITLE")).getText(), "Pagar Cuotas - Paso 2 de 3");
			String texto = driver.findElement(By.id("TEXTBLOCKTITLE")).getText();
			System.out.println("Paso 1 realizado de manera exitosa, t�tulo de p�gina actual: " + texto);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		Thread.sleep(1000);
		String montoDesc1 = driver.findElement(By.xpath("//td/table/tbody/tr/td[6]/span")).getText();
		driver.findElement(By.id("MODIFDESCINTERESES")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("vRECAUDACIONDESCINTERESESMORA")).clear();
		driver.findElement(By.id("vRECAUDACIONDESCINTERESESMORA")).sendKeys("35,20%");
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);
		driver.findElement(By.id("MODIFDESCGASTOS")).click();
		Thread.sleep(1000);
		String montoDesc2 = driver.findElement(By.id("span_vRECAUDACIONINTERESESMORAFINAL")).getText();
		if (montoDesc1 != montoDesc2) {
			System.out.println("Porcentaje de descuento aplicado de manera exitosa");
		} else {
			System.out.println("Error al aplicar descuento");
		}
		Thread.sleep(1000);
		driver.findElement(By.id("vRECAUDACIONDESCGASTOSCOBRANZA")).clear();
		driver.findElement(By.id("vRECAUDACIONDESCGASTOSCOBRANZA")).sendKeys("7,4");
		Thread.sleep(1000);
		driver.findElement(By.id("MODIFDESCINTERESES")).click();
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		Thread.sleep(10000);
		try {
			assertEquals(driver.findElement(By.id("TEXTBLOCKTITLE")).getText(), "Pagar Cuotas - Paso 3 de 3");
			String texto2 = driver.findElement(By.id("TEXTBLOCKTITLE")).getText();
			System.out.println("Paso 2 realizado de manera exitosa, t�tulo de p�gina actual: " + texto2);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		String totalAbonar = driver.findElement(By.xpath("//*[@id=\"span_vTOTALCONIVA\"]")).getText();
		new Select(driver.findElement(By.id("vFORMADEPAGOID"))).selectByVisibleText("Efectivo");
		Thread.sleep(10000);
		driver.findElement(By.id("vRECAUDACIONFORMADEPAGOMONTO")).clear();
		driver.findElement(By.id("vRECAUDACIONFORMADEPAGOMONTO")).sendKeys(totalAbonar);
		Thread.sleep(1000);
		driver.findElement(By.id("AGREGAR")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("BTNCONFIRMAR")).click();
		Thread.sleep(6000);
		boolean confirmarPagoCuotas = isElementPresent(By.xpath("//div/div/div/div[2]"));
		if (confirmarPagoCuotas == true) {
			driver.findElement(By.id("DVELOP_CONFIRMPANEL_BTNCONFIRMARContainer_SaveButton")).click();
		} else {
			System.out.println("Error al confirmar pago de cuotas");
		}
		Thread.sleep(10000);
		try {
			assertEquals(driver.getTitle(), "Recaudacion");
			System.out.println("Nueva recaudaci�n realizada de manera exitosa");
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}