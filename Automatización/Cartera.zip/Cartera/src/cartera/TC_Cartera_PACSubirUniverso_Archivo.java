package cartera;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TC_Cartera_PACSubirUniverso_Archivo {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PACSubirUniverso";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PACSubirUniverso.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTCCarteraPACSubirUniversoArchivo() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[6]/a/span")).click();
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			logEjecucion.append("Ingreso al m�dulo PAC ");
			System.out.println("Ingreso al m�dulo PAC");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//div[7]/a[5]")).click();
			logEjecucion.append("Ingreso al sub m�dulo Subir Universo ");
			System.out.println("Ingreso al sub m�dulo Subir Universo");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("fileuploadUPLOADIFYHTML51Container")).sendKeys("C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/Universo.xlsx");
			logEjecucion.append("Se procede a subir archivo ");
			System.out.println("Se procede a subir archivo");
			getFoto(driver);
			Thread.sleep(40000);
			try {
				assertEquals(driver.findElement(By.id("INDICADORESTITLE")).getText(), "Indicadores");
				logEjecucion.append(driver.findElement(By.id("INDICADORESTITLE")).getText() + " ");
				System.out.println(driver.findElement(By.id("INDICADORESTITLE")).getText());
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append(verificationErrors.append(e.toString()) + " ");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}