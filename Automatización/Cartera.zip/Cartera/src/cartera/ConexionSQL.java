package cartera;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public final class ConexionSQL{

    private static ConexionSQL INSTANCIA = null;
    private static Properties PROPIEDADES = new File_Propiedades().getProperties(TipoFile.config);
    static Connection conexion = null;
    private String user, pass, ip, puerto, database, url;
    
    public ConexionSQL(){
        this.user = PROPIEDADES.getProperty("user");
        this.pass = PROPIEDADES.getProperty("password");
        this.ip = PROPIEDADES.getProperty("ipbd");
        this.puerto = PROPIEDADES.getProperty("puerto");
        this.database = PROPIEDADES.getProperty("db_name");
        this.url = "jdbc:sqlserver:" + this.ip + ":" + this.puerto + ";" + this.database;
        conectar();
        INSTANCIA = this;
    }
    
        public boolean conectar() {
        boolean isConect = true;
        try {
            
            String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(driver);
            conexion = DriverManager.getConnection(this.url, this.user, this.pass);
        } catch (SQLException e) {
            System.err.println("causa: \n"+  e.getCause());
            System.err.println("El sistema no conecta a BD :" + this.database);
            isConect = false;
        } catch (ClassNotFoundException ex) {
            System.err.println("causa: \n"+  ex.getCause());
            
        }
        return isConect;
    }

    private synchronized static void creaInstancia() {
        if (INSTANCIA == null) {
            INSTANCIA = new ConexionSQL();
        }
    }

    public static ConexionSQL getInstancia() {
        if (INSTANCIA == null) {
            creaInstancia();            
        }
        return INSTANCIA;
    }

    public Connection getConexion() {
        return conexion;
    }

    public void cerrarConexion() {
        try {
            conexion.close();
        } catch (SQLException e) {
            System.err.println("El sistema fallo al cerrar conexi�n a bd:" + this.database);
            System.err.println("" + e.getMessage());
        }
    }
}