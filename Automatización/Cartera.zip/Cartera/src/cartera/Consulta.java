package cartera;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Consulta {

	private String op, alzamientoLeasing, forzarAlzamiento;

	public void setOp(String op) {
		this.op = op;
	}

	public String getOp() {
		return op;
	}
	
	public void setAlzamientoLeasing(String alzamientoLeasing) {
		this.alzamientoLeasing = alzamientoLeasing;
	}
	
	public String getAlzamientoLeasing() {
		return alzamientoLeasing;
	}
	
	public void setForzarAlzamiento(String forzarAlzamiento) {
		this.forzarAlzamiento = forzarAlzamiento;
	}
	
	public String getForzarAlzamiento() {
		return forzarAlzamiento;
	}

	public void generarOP() {
		String query;
		ConexionSQL conexion = ConexionSQL.getInstancia();
		Statement sentencia = null;
		PreparedStatement prpSentencia = null;
		ResultSet rs = null;
		try {
			query = ("Select TOP 1 t1.crenroope from Creditos t1\r\n"
					+ "inner join CreditosDetalleCredito t2 on t2.crenroope=t1.crenroope\r\n"
					+ "left join recaudacion t3 on t3.crenroope=t1.crenroope and RecaudacionEstado in (1,3)\r\n"
					+ "where CreEstadoContrato=1 and CreEstadoPago=2 and DetCreFchVenCuo>'01-01-2019' and DetCreFchPagCuo is null group by t1.crenroope order by t1.crenroope desc\r\n");
			sentencia = conexion.getConexion().createStatement();
			rs = sentencia.executeQuery(query);
			while (rs.next()) {
				setOp(rs.getString("crenroope"));
			}
			rs.close();
			sentencia.close();
		} catch (SQLException ex) {
			System.out.println("Fallo en BD: " + ex);
		}
	}
	
	public void generarAlzamientosLeasing() {
		String query;
		ConexionSQL conexion = ConexionSQL.getInstancia();
		Statement sentencia = null;
		PreparedStatement prpSentencia = null;
		ResultSet rs = null;
		try {
			query = ("Select TOP 1 crenroope,SolicitudTipoCredito,CreEstadoContrato,CreEnCambioDePrenda,CreAlzamientoPendienteCambioPrenda from Creditos t1\r\n" + 
					"inner join gemma.dbo.simulacion t2 on t2.simulacioncodigo=t1.crenroope\r\n" + 
					"inner join gemma.dbo.solicitudfinanciamiento t3 on t3.simulacionid=t2.simulacionid\r\n" + 
					"where CreEstadoContrato=1 and CreEnCambioDePrenda=1 and CreAlzamientoPendienteCambioPrenda=1\r\n");
			sentencia = conexion.getConexion().createStatement();
			rs = sentencia.executeQuery(query);
			while (rs.next()) {
				setAlzamientoLeasing(rs.getString("crenroope"));
			}
			rs.close();
			sentencia.close();
		} catch (SQLException ex) {
			System.out.println("Fallo en BD: " + ex);
		}
	}
	
	public void generarForzarAlzamiento () {
		String query;
		ConexionSQL conexion = ConexionSQL.getInstancia();
		Statement sentencia = null;
		PreparedStatement prpSentencia = null;
		ResultSet rs = null;
		try {
			query = ("Select TOP 1 crenroope,SolicitudTipoCredito,CreEstadoContrato,CreEnCambioDePrenda,CreAlzamientoPendienteCambioPrenda,CreEstadoAlzamiento from Creditos t1\r\n" + 
					"inner join gemma.dbo.simulacion t2 on t2.simulacioncodigo=t1.crenroope\r\n" + 
					"inner join gemma.dbo.solicitudfinanciamiento t3 on t3.simulacionid=t2.simulacionid\r\n" + 
					"where CreEstadoContrato=1 and CreEnCambioDePrenda=1 and CreAlzamientoPendienteCambioPrenda=1\r\n");
			sentencia = conexion.getConexion().createStatement();
			rs = sentencia.executeQuery(query);
			while (rs.next()) {
				setForzarAlzamiento(rs.getString("crenroope"));
			}
			rs.close();
			sentencia.close();
		} catch (SQLException ex) {
			System.out.println("Fallo en BD: " + ex);
		}
	}
}