package cartera;

public class Consulta {

}
