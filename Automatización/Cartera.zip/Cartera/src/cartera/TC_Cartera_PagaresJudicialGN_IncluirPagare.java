package cartera;

import org.testng.Assert;
import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_PagaresJudicialGN_IncluirPagare {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PagaresJudicialGN_IP";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PagaresJudicialGN_IP.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTC_Cartera_PagaresJudicialGNIncluirPagare() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[16]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[17]/a[2]")).click();
			logEjecucion.append("Ingreso al m�dulo Pagares a judicial, subm�dulo Genarar Nomina ");
			System.out.println("Ingreso al m�dulo Pagares a judicial, subm�dulo Genarar Nomina");
			getFoto(driver);
			Thread.sleep(8000);
			boolean nominaGenerada = isElementPresent(By.xpath("//div/div/div/div[2]"));
			if (nominaGenerada == true) {
				driver.findElement(By.id("DVELOP_BOOTSTRAP_CONFIRMPANEL1Container_DismissButton")).click();
				logEjecucion.append("Opci�n No ");
				System.out.println("Opci�n No");
				getFoto(driver);
				Thread.sleep(6000);
				new Select(driver.findElement(By.id("vCREPOLITICAJSELECCION"))).selectByVisibleText("(Todas)");
				logEjecucion.append("Filtrar por tipo de politica Todas ");
				System.out.println("Filtrar por tipo de politica Todas");
				getFoto(driver);
				Thread.sleep(15000);
				new Select(driver.findElement(By.id("vCREPOLITICAJDESMARCA"))).selectByVisibleText("Si");
				logEjecucion.append("Filtrar Excluidos Si ");
				System.out.println("Filtrar Excluidos Si");
				getFoto(driver);
				Thread.sleep(15000);
				String op1 = driver.findElement(By.xpath("//td[4]/span/a")).getText();
				driver.findElement(By.id("vIMGMARCA_0001")).click();
				logEjecucion.append("Seleccionar OP ");
				System.out.println("Seleccionar OP");
				getFoto(driver);
				Thread.sleep(5000);
				driver.findElement(By.id("DVELOP_CONFIRMPANEL_IMGMARCAContainer_SaveButton")).click();
				logEjecucion.append("Incluir pagare ");
				System.out.println("Incluir pagare");
				getFoto(driver);
				Thread.sleep(8000);
				String op2 = driver.findElement(By.xpath("//td[4]/span/a")).getText();
				if (op1 == op2) {
					logEjecucion.append("Error al incluir pagare ");
					System.out.println("Error al incluir pagare");
					getFoto(driver);
					Thread.sleep(1000);
					Assert.fail();
				} else {
					logEjecucion.append("Pagare inluido correctamente ");
					System.out.println("Pagare inluido correctamente");
					getFoto(driver);
					Thread.sleep(1000);
				}
			} else {
				new Select(driver.findElement(By.id("vCREPOLITICAJSELECCION"))).selectByVisibleText("(Todas)");
				logEjecucion.append("Filtrar por tipo de politica Todas ");
				System.out.println("Filtrar por tipo de politica Todas");
				getFoto(driver);
				Thread.sleep(15000);
				new Select(driver.findElement(By.id("vCREPOLITICAJDESMARCA"))).selectByVisibleText("Si");
				logEjecucion.append("Filtrar Excluidos Si ");
				System.out.println("Filtrar Excluidos Si");
				getFoto(driver);
				Thread.sleep(15000);
				String op1 = driver.findElement(By.xpath("//td[4]/span/a")).getText();
				driver.findElement(By.id("vIMGMARCA_0001")).click();
				logEjecucion.append("Seleccionar OP ");
				System.out.println("Seleccionar OP");
				getFoto(driver);
				Thread.sleep(5000);
				driver.findElement(By.id("DVELOP_CONFIRMPANEL_IMGMARCAContainer_SaveButton")).click();
				logEjecucion.append("Incluir pagare ");
				System.out.println("Incluir pagare");
				getFoto(driver);
				Thread.sleep(8000);
				String op2 = driver.findElement(By.xpath("//td[4]/span/a")).getText();
				if (op1 == op2) {
					logEjecucion.append("Error al incluir pagare ");
					System.out.println("Error al incluir pagare");
					getFoto(driver);
					Thread.sleep(1000);
					Assert.fail();
				} else {
					logEjecucion.append("Pagare inluido correctamente ");
					System.out.println("Pagare inluido correctamente");
					getFoto(driver);
					Thread.sleep(1000);
				}
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA); 
			zip.comprimir();
			Thread.sleep(5000); 
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(),className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}