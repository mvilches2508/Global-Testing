package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Cheques_Remplazado {

	private WebDriver driver;
	private String baseUrl;
	
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "D:/Cartera/bin/cartera/evidencia/ChequesRemplazado";
	private static final String EVIDENCIAZIP = "D:/Cartera/bin/cartera/evidencia/ChequesRemplazado.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();
	
	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraChequesRemplazado() throws Exception {
		try {
		Robot robot = new Robot();
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[6]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		logEjecucion.append("Acceso al men� cheque");
		getFoto(driver);
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCHEQUEESTADO1"))).selectByVisibleText("REEMPLAZADO");
		logEjecucion.append("Seleccionar cheque en estado reemplazado");
		getFoto(driver);
		Thread.sleep(10000);
		String nroCheque = driver.findElement(By.xpath("//td[8]/span/a")).getText();
		System.out.println("Nro de cheque seleccionado: "+nroCheque);
		logEjecucion.append("Nro de cheque seleccionado: "+nroCheque);
		getFoto(driver);
		driver.findElement(By.id("vIMPRIMECOMPROBANTE_0001")).click();
		logEjecucion.append("Imprimir comprobante");
		getFoto(driver);
		Thread.sleep(10000);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}
	
	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}