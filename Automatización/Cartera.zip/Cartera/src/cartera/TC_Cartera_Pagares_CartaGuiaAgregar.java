package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Pagares_CartaGuiaAgregar {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/CartaGuiaAgregar";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/CartaGuiaAgregar.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "https://www.gemma.cl/cartera2019/seclogin.aspx";
	}

	@Test
	public void testTCCarteraPagaresCartaGuiaAgregar() throws Exception {
		try {
			driver.get(baseUrl);
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//tr[8]/td/table/tbody/tr/td[2]/p/span/a")).click();
			logEjecucion.append("Acceso al men� Pagares");
			System.out.println("Acceso al men� Pagares");
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.id("INSERTARCARTAGUIAPAGARE")).click();
			logEjecucion.append("Se procede a filtrar insertar carta guia");
			System.out.println("Se procede a filtrar insertar carta guia");
			getFoto(driver);
			Thread.sleep(10000);
			new Select(driver.findElement(By.id("vUBICACIONESPAGARES"))).selectByVisibleText("Banco Itau");
			logEjecucion.append("Ubicacion seleccionada banco itau");
			System.out.println("Ubicacion seleccionada banco itau");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vINVERSIONISTA"))).selectByVisibleText("No Aplica");
			logEjecucion.append("Inversionista: no aplica");
			System.out.println("Inversionista: no aplica");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vUBICACIONESPAGAREFISICAID"))).selectByVisibleText("Itau");
			logEjecucion.append("Ubicacion pagare: Itau");
			System.out.println("Ubicacion pagare: Itau");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vMOTIVOTRASLADOID"))).selectByVisibleText("N/A");
			logEjecucion.append("Motivo traslado: N/A");
			System.out.println("Motivo traslado: N/A");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			logEjecucion.append("Confirmar accion");
			System.out.println("Confirmar accion");
			getFoto(driver);
			Thread.sleep(18000);
			String nomina = driver.findElement(By.id("span_vCARTAGUIANOMINA")).getText();
			System.out.println("Nro de nomina generada: "+nomina);
			logEjecucion.append("Nro de nomina generada: "+nomina);
			driver.findElement(By.id("vAGREGARPAGARE_0001")).click();
			logEjecucion.append("Agregar pagare");
			System.out.println("Agregar pagare");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vAGREGARPAGARE_0001")).click();
			logEjecucion.append("Agregar pagare");
			System.out.println("Agregar pagare");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vAGREGARPAGARE_0001")).click();
			logEjecucion.append("Agregar pagare");
			System.out.println("Agregar pagare");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNCANCELAR")).click();
			logEjecucion.append("Retornar");
			System.out.println("Retornar");
			getFoto(driver);
			Thread.sleep(18000);
			driver.findElement(By.xpath("//td[10]/span/a")).click();
			logEjecucion.append("Consultar registro");
			System.out.println("Consultar registro");
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//td[2]/table/tbody/tr/td/span/a")).click();
			logEjecucion.append("Consultar registro");
			System.out.println("Consultar registro");
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//td[2]/span/a")).click();
			logEjecucion.append("Consultar registro");
			System.out.println("Consultar registro");
			getFoto(driver);
			Thread.sleep(3000);
			driver.findElement(By.id("vVERCARTAGUIAPAGARE_0001")).click();
			logEjecucion.append("Consultar registro");
			System.out.println("Consultar registro");
			getFoto(driver);
			Thread.sleep(10000);
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}