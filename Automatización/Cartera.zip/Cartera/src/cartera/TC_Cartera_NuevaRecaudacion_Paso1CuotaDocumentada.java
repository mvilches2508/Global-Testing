package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1CuotaDocumentada {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso1CuotaDocumentada() throws Exception {
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		driver.get(baseUrl);
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys("mvalles");
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys("Mvll18.");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(15000);
		driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(5000);
		boolean mensajeNR = isElementPresent(By.id("TEXTBLOCKTITLE"));
		if (mensajeNR == true) {
			System.out.println("Nueva Recaudaci�n");
		} else {
			System.out.println("No accede ala funcionalidad");
		}
		driver.findElement(By.id("vCRENROOPE")).clear();
		driver.findElement(By.id("vCRENROOPE")).sendKeys("1100582");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNBUSCAR")).click();
		Thread.sleep(10000);
		boolean op = isElementPresent(By.id("vSELECCIONAR_0001"));
		if (op == true) {
			driver.findElement(By.id("vSELECCIONAR_0001")).click();
			System.out.println("OP seleccionada");
			Thread.sleep(3000);
		} else {
			System.out.println("Error al seleccinar OP");
		}
		new Select(driver.findElement(By.id("vMOSTRARCUOTAS"))).selectByVisibleText("Todas");
		Thread.sleep(10000);
		WebElement checkBox = driver.findElement(By.id("vGRIDCUOTASSELECTED_0001"));
		checkBox.isDisplayed();
		if (!checkBox.isSelected()) {
			checkBox.click();
			System.out.println("Cuota seleccionada");
			Thread.sleep(2000);
		} else {
			System.out.println("Error al seleccionar cuotas");
		}
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		Thread.sleep(5000);
		try {
			assertEquals(driver.findElement(By.xpath("//span/div")).getText(),
					"No es posible recaudar esta cuota porque tiene cuotas anteriores documentadas");
			String mensaje = driver.findElement(By.xpath("//span/div")).getText();
			System.out.println("Verificaci�n exitosa: " + mensaje);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}