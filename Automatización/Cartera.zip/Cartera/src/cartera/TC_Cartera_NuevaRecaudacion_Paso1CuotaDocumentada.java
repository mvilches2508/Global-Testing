package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1CuotaDocumentada {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/NRPaso1Cuota";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/NRPaso1Cuota.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "https://www.gemma.cl/cartera2019/seclogin.aspx";
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso1CuotaDocumentada() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(15000);
		driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(5000);
		boolean mensajeNR = isElementPresent(By.id("TEXTBLOCKTITLE"));
		if (mensajeNR == true) {
			System.out.println("Nueva Recaudaci�n");
			logEjecucion.append("Nueva Recaudaci�n");
			getFoto(driver);
		} else {
			System.out.println("No accede ala funcionalidad");
			logEjecucion.append("No accede ala funcionalidad");
			getFoto(driver);
		}
		driver.findElement(By.id("vCRENROOPE")).clear();
		driver.findElement(By.id("vCRENROOPE")).sendKeys("1100582");
		logEjecucion.append("Ingresar nro de OP 1100582");
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNBUSCAR")).click();
		logEjecucion.append("Presionar boton buscar");
		getFoto(driver);
		Thread.sleep(10000);
		boolean op = isElementPresent(By.id("vSELECCIONAR_0001"));
		if (op == true) {
			driver.findElement(By.id("vSELECCIONAR_0001")).click();
			System.out.println("OP seleccionada");
			logEjecucion.append("OP seleccionada");
			getFoto(driver);
			Thread.sleep(3000);
		} else {
			System.out.println("Error al seleccinar OP");
			logEjecucion.append("Error al seleccinar OP");
			getFoto(driver);
		}
		new Select(driver.findElement(By.id("vMOSTRARCUOTAS"))).selectByVisibleText("Todas");
		logEjecucion.append("Mostrar cuotas");
		getFoto(driver);
		Thread.sleep(10000);
		WebElement checkBox = driver.findElement(By.id("vGRIDCUOTASSELECTED_0001"));
		checkBox.isDisplayed();
		if (!checkBox.isSelected()) {
			checkBox.click();
			System.out.println("Cuota seleccionada");
			logEjecucion.append("Cuota seleccionada");
			getFoto(driver);
			Thread.sleep(2000);
		} else {
			System.out.println("Error al seleccionar cuotas");
			logEjecucion.append("Error al seleccionar cuotas");
			getFoto(driver);
		}
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		logEjecucion.append("Presionar boton siguiente");
		getFoto(driver);
		Thread.sleep(5000);
		try {
			assertEquals(driver.findElement(By.xpath("//span/div")).getText(),
					"No es posible recaudar esta cuota porque tiene cuotas anteriores documentadas");
			String mensaje = driver.findElement(By.xpath("//span/div")).getText();
			System.out.println("Verificaci�n exitosa: " + mensaje);
			logEjecucion.append("Verificaci�n exitosa: " + mensaje);
			getFoto(driver);
		} catch (Error e) {
			verificationErrors.append(e.toString());
			logEjecucion.append(verificationErrors.append(e.toString()));
			getFoto(driver);
		}
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}