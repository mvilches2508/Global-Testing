package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_ConvencionalJudicial {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "bin/cartera/evidencia/ConvencionalJudicial";
	private static final String EVIDENCIAZIP = "bin/cartera/evidencia/ConvencionalJudicial.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraCreditosConvencionalJudicial() throws Exception {
		try {
		driver.get(baseUrl);
		credenciales.generar();
		Thread.sleep(8000);
		getFoto(driver);
		Thread.sleep(1000);
		logEjecucion.append("Se ingresa a la p�g: "+baseUrl+" ");
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
		logEjecucion.append("Se ingresa las siguientes credenciales: "+credenciales.getUser()+" "+credenciales.getPass());
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		getFoto(driver);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//span/a")).click();
		Thread.sleep(10000);
		boolean formulario = isElementPresent(By.id("CREDITOSTITLE"));
		if(formulario==true) {
			System.out.println("Acceso al men� cr�ditos");
			logEjecucion.append("Acceso al men� cr�ditos");
			getFoto(driver);
		}else {
			System.out.println("Error al acceder al men� cr�ditos");
			logEjecucion.append("Error al acceder al men� cr�ditos");
			getFoto(driver);
		}
		driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
		logEjecucion.append("Considerar filtro");
		getFoto(driver);
		Thread.sleep(20000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
		logEjecucion.append("Filtro tipo cr�dito");
		getFoto(driver);
		Thread.sleep(15000);
		new Select(driver.findElement(By.id("vSOLICITUDTIPOCREDITO1"))).selectByVisibleText("CONVENCIONAL");
		logEjecucion.append("opcion convencional");
		getFoto(driver);
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
		logEjecucion.append("Filtro estado pago");
		getFoto(driver);
		Thread.sleep(15000);
		new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("JUDICIAL");
		logEjecucion.append("Opcion Judicial");
		getFoto(driver);
		Thread.sleep(10000);
		String op = driver.findElement(By.xpath("//tr[9]/td[3]/span/a")).getText();
		System.out.println("N�mero de OP seleccionada: "+op);
		logEjecucion.append("N�mero de OP seleccionada: "+op);
		getFoto(driver);
		driver.findElement(By.id("vEDITARCONVENIDO_0008")).click();
		logEjecucion.append("Editar");
		getFoto(driver);
		Thread.sleep(10000);
		String estado1 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		System.out.println("Estado de cuota nro 1: "+estado1);
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0002")).sendKeys("291118");
		logEjecucion.append("Estado de cuota nro 1: "+estado1);
		getFoto(driver);
		Thread.sleep(1000);
		String estado2 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0003")).getText();
		System.out.println("Estado de cuota nro 2: "+estado2);
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0003")).clear();
		driver.findElement(By.id("SDTCONVENIDO__DETCREFCHVENCUO_0003")).sendKeys("291218");
		logEjecucion.append("Se ingesa codigo 291218" );
		getFoto(driver);
		Thread.sleep(1000);
		driver.findElement(By.id("BTNCONFIRMAR")).click();
		logEjecucion.append("Confirmar edicion" );
		getFoto(driver);
		Thread.sleep(20000);
		driver.findElement(By.id("vEDITARCONVENIDO_0008")).click();
		logEjecucion.append("Verificar edicion");
		getFoto(driver);
		Thread.sleep(10000);
		String estado3 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0002")).getText();
		String estado4 = driver.findElement(By.id("span_SDTCONVENIDO__DETCREESTCUO_0003")).getText();
		if(estado1!=estado3 && estado2!=estado4) {
			System.out.println("Estado de cuotas actualizado de manera exitosa: "+estado3+" "+estado4);
			logEjecucion.append("Estado de cuotas actualizado de manera exitosa: "+estado3+" "+estado4);
			getFoto(driver);
		}else {
			System.out.println("Error al actualizar estado de cuotas: "+estado3+" "+estado4);
			logEjecucion.append("Error al actualizar estado de cuotas: "+estado3+" "+estado4);
			getFoto(driver);
		}
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw(e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
		zip.comprimir();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}