package cartera;

public enum TipoFile {

	config
}