package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TC_Cartera_ProcesoRemesa_EnlaceGeneral {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PREnlaceGeneral";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PREnlaceGeneral.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraProcesoRemesaEnlaceGeneral() throws Exception {
		try {
			Robot robot = new Robot();
			driver.get(baseUrl);
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�gina: " + baseUrl + " ");
			System.out.println("Se ingresa a la p�gina: " + baseUrl + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[10]/a/span")).click();
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			logEjecucion.append("Ingreso al m�dulo Procesos ");
			System.out.println("Ingreso al m�dulo Procesos ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//div[11]/a[8]")).click();
			logEjecucion.append("Ingreso al subm�dulo Trabajar con remesas ");
			System.out.println("Ingreso al subm�dulo Trabajar con remesas ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vIMGPDF_0002")).click();
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Descargar PDF ");
			System.out.println("Descargar PDF ");
			robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//tr[2]/td[4]/span/a")).click();
			getFoto(driver);
			Thread.sleep(6000);
			boolean remesa = isElementPresent(By.id("VIEWTITLE"));
			if (remesa == true) {
				logEjecucion.append("Consulta realizada de manera exitosa");
				System.out.println("Consulta realizada de manera exitosa");
			} else {
				logEjecucion.append("Error al realizar consulta");
				System.err.println("Error al realizar consulta");
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}