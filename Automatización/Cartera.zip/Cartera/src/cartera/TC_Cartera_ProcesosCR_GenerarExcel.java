package cartera;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_Cartera_ProcesosCR_GenerarExcel {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/ProcesosCR";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/ProcesosCR.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();
	int dia = 06;
	int mes = 01;
	int anno = 19;

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void testTC_Cartera_ProcesosCR_GenerarExcel() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[10]/a/span")).click();
			getFoto(driver);
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[11]/a[5]")).click();
			getFoto(driver);
			Thread.sleep(5000);
			logEjecucion.append("Ingreso al m�dulo Procesos,sub m�dulo Centralizaci�n Recaudaciones ");
			System.out.println("Ingreso al m�dulo Procesos,sub m�dulo Centralizaci�n Recaudaciones");
			driver.findElement(By.id("INSERTAR")).click();
			getFoto(driver);
			Thread.sleep(3000);
			logEjecucion.append("Se procede a contabilizar recaudaci�n ");
			System.out.println("Se procede a contabilizar recaudaci�n");
			driver.findElement(By.id("vCONTRECFECHA")).clear();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vCONTRECFECHA').value=" + dia + "+'/'+" + mes + "+'/'+" + anno + ";");
			System.out.println("Se ingresa fecha: " + dia + "/" + mes + "/" + anno);
			logEjecucion.append("Se ingresa fecha: " + dia + "/" + mes + "/" + anno + " ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vCONTRECGLOSA")).clear();
			driver.findElement(By.id("vCONTRECGLOSA")).sendKeys("Recaudacion");
			logEjecucion.append("Glosa: recaudaci�n ");
			System.out.println("Glosa: recaudaci�n");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			logEjecucion.append("Presionar bot�n confirmar ");
			System.out.println("Presionar bot�n confirmar ");
			getFoto(driver);
			Thread.sleep(3000);
			try {
				assertEquals(driver.findElement(By.xpath("//span/div")).getText(),"No se encontraron registros para la fecha seleccionada");
				logEjecucion.append("Mensaje: " + driver.findElement(By.xpath("//span/div")).getText() + " ");
				System.out.println("Mensaje: " + driver.findElement(By.xpath("//span/div")).getText());
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append("Mensaje: " + verificationErrors.append(e.toString()) + " ");
				System.out.println("Mensaje: " + verificationErrors.append(e.toString()));
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("BTN_CANCEL")).click();
			logEjecucion.append("Retornar ");
			System.out.println("Retornar");
			getFoto(driver);
			Thread.sleep(3000);
			String comprobante1 = driver.findElement(By.id("span_CONTRECNROCOMPROBANTE_0015")).getText();
			driver.findElement(By.id("vEDITARNROCOMPROBANTE_0015")).click();
			logEjecucion.append("Seleccionar nro de comporbante: " + comprobante1 + " ");
			System.out.println("Seleccionar nro de comporbante: " + comprobante1 + " ");
			getFoto(driver);
			Thread.sleep(3000);
			driver.switchTo().frame("gxp0_ifrm");
			driver.findElement(By.id("vCONTRECNROCOMPROBANTE")).clear();
			driver.findElement(By.id("vCONTRECNROCOMPROBANTE")).sendKeys("1017003");
			logEjecucion.append("Ingresar nro de comporbante ");
			System.out.println("Ingresar nro de comporbante");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			logEjecucion.append("Presionar bot�n confirmar ");
			System.out.println("Presionar bot�n confirmar ");
			getFoto(driver);
			Thread.sleep(120000);
			driver.switchTo().defaultContent();
			Thread.sleep(1000);
			String comprobante2 = driver.findElement(By.id("span_CONTRECNROCOMPROBANTE_0015")).getText();
			if (comprobante1 == comprobante2) {
				logEjecucion.append("Nro de comporbante actualizado: " + comprobante2 + " ");
				System.out.println("Nro de comporbante actualizado: " + comprobante2);
				getFoto(driver);
				Thread.sleep(1000);
			} else {
				logEjecucion.append("Error al actualizar nro de comprobante ");
				System.err.println("Error al actualizar nro de comprobante");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("vDELETE_0002")).click();
			logEjecucion.append("Se procede a eliminar registro ");
			System.out.println("Se procede a eliminar registro");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTN_TRN_ENTER")).click();
			logEjecucion.append("Se confirma eliminaci�n de registro ");
			System.out.println("Se confirma eliminaci�n de registro");
			getFoto(driver);
			Thread.sleep(20000);
			driver.findElement(By.id("vEXPORTAREXCEL_0001")).click();
			logEjecucion.append("Descargar excel ");
			System.out.println("Descargar excel");
			getFoto(driver);
			Thread.sleep(120000);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}