package cartera;

public class Credenciales {

	private String user, pass;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public void generar() {
		setUser("mvalles");
		setPass("vllM.18");
	}
}