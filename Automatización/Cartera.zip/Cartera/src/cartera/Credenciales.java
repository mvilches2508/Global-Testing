package cartera;

public class Credenciales {

	private String user, pass, baseURL;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public String getBaseURL() {
		return baseURL;
	}
	
	public void setBaseURL(String baseURL) {
		this.baseURL = baseURL;
	}

	public void generar() {
		setUser("Administrador");
		setPass("itfactory2014");
		setBaseURL("http://54.235.81.157/carteragx16/seclogin.aspx");
		//setBaseURL("54.235.81.157/carteratest/seclogin.aspx");
	}
}