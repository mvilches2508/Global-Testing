package cartera;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1ConceptoRecaudacion {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/NRPaso1Concepto";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/NRPaso1Concepto.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso1Credito() throws Exception {
		try {
			credenciales.generar();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
			Thread.sleep(8000);
			new Select(driver.findElement(By.id("vCREESTADOCONTRATO"))).selectByVisibleText("VIGENTE");
			logEjecucion.append("Acceso al menu Nueva Recaudacion, se procede a buscar OP en estado Vigente ");
			System.out.println("Acceso al menu Nueva Recaudacion, se procede a buscar OP en estado Vigente");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNBUSCAR")).click();
			logEjecucion.append("Presionar boton buscar ");
			System.out.println("Presionar boton buscar");
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.id("vSELECCIONAR_0008")).click();
			logEjecucion.append("Seleccionar registro ");
			System.out.println("Seleccionar registro");
			getFoto(driver);
			Thread.sleep(5000);
			String op = driver.findElement(By.id("span_CRENROOPE_0008")).getText();
			System.out.println("Nro de OP seleccionado: " + op);
			logEjecucion.append("Nro de OP seleccionado: " + op + " ");
			new Select(driver.findElement(By.id("vRECAUDACIONOTROSID"))).selectByVisibleText("Otros");
			logEjecucion.append("Recaudacion otros ");
			System.out.println("Recaudacion otros");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vGRIDCUOTASSELECTED_0001")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("vGRIDCUOTASSELECTED_0002")).click();
			logEjecucion.append("Seleccionar cuotas ");
			System.out.println("Seleccionar cuotas");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNSIGUIENTE")).click();
			logEjecucion.append("Recaudacion otros ");
			System.out.println("Recaudacion otros");
			getFoto(driver);
			Thread.sleep(10000);
			driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
			boolean ingresarFecha = isElementPresent(By.id("vCREFCHPAGOREAL"));
			if (ingresarFecha == true) {
				SimpleDateFormat dia = new SimpleDateFormat("dd");
				SimpleDateFormat mes = new SimpleDateFormat("MM");
				SimpleDateFormat anno = new SimpleDateFormat("yy");
				String diaActual = dia.format(new Date());
				String mesActual = mes.format(new Date());
				String annoActual = anno.format(new Date());
				int diaHoy = Integer.parseInt(diaActual);
				int mesHoy = Integer.parseInt(mesActual);
				int annoHoy = Integer.parseInt(annoActual);
				System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("document.getElementById('vCREFCHPAGOREAL').value=" + diaHoy + "+'/'+" + mesActual+ "+'/'+" + annoActual + ";");
				logEjecucion.append("Ingresar Fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy + " ");
				getFoto(driver);
				Thread.sleep(1000);
			} else {
				System.out.println("Error al ingresar fecha");
				logEjecucion.append("Error al ingresar fecha ");
				getFoto(driver);
			}
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			logEjecucion.append("Presionar boton continuar ");
			System.out.println("Presionar boton continuar");
			getFoto(driver);
			driver.switchTo().defaultContent();
			Thread.sleep(10000);
			boolean uf = isElementPresent(By.xpath("//*[@id=\"gxErrorViewer\"]/div/text()"));
			if (uf == true) {
				System.out.println("No es posible crear paso debido a: No existe definici�n de UF para la fecha de pago. Para continuar deber� cargar la UF para la fecha de pago.");
				logEjecucion.append("No es posible crear paso debido a: No existe definici�n de UF para la fecha de pago. Para continuar deber� cargar la UF para la fecha de pago. ");
				getFoto(driver);
			} else {
				System.out.println("Paso crear de manera exitosa");
				logEjecucion.append("Paso crear de manera exitosa ");
			}
			Thread.sleep(3000);
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}