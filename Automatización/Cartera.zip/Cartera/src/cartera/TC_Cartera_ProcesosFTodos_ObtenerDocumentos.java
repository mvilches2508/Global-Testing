package cartera;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_ProcesosFTodos_ObtenerDocumentos {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PTodosDocumentos";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PTodosDocumentos.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void testFlujo() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[12]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			driver.findElement(By.xpath("//div[13]/a")).click();
			logEjecucion.append("Ingreso al m�dulo Procesos, subm�dulo Todos ");
			System.out.println("Ingreso al m�dulo Procesos, subm�dulo Todos");
			getFoto(driver);
			Thread.sleep(90000);
			driver.findElement(By.id("INSERT")).click();
			logEjecucion.append("Ingresar nuevo proceso ");
			System.out.println("Ingresar nuevo proceso");
			getFoto(driver);
			Thread.sleep(5000);
			driver.findElement(By.id("PROCESOTIPOID")).clear();
			driver.findElement(By.id("PROCESOTIPOID")).sendKeys("10");
			logEjecucion.append("ID proceso: 10 ");
			System.out.println("ID proceso: 10");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("PROCESONROOPERACION")).clear();
			driver.findElement(By.id("PROCESONROOPERACION")).sendKeys("180288377");
			logEjecucion.append("Nro OP: 180288377 ");
			System.out.println("Nro OP: 180288377");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTN_TRN_ENTER")).click();
			logEjecucion.append("Procesar ");
			System.out.println("Procesar");
			getFoto(driver);
			Thread.sleep(15000);
			new Select(driver.findElement(By.id("vPROCESOTIPOID"))).selectByVisibleText("Prenda");
			logEjecucion.append("Filtrar registro por Prenda ");
			System.out.println("Filtrar registro por Prenda");
			getFoto(driver);
			Thread.sleep(20000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado Proceso");
			logEjecucion.append("Filtrar Estado Proceso ");
			System.out.println("Filtrar Estado Proceso");
			getFoto(driver);
			Thread.sleep(20000);
			new Select(driver.findElement(By.id("vPROCESOESTADO1"))).selectByVisibleText("Terminado");
			logEjecucion.append("Filtrar Estado Terminado ");
			System.out.println("Filtrar Estado Terminado");
			getFoto(driver);
			Thread.sleep(20000);
			driver.findElement(By.id("vGETDOCUMENTOS_0006")).click();
			logEjecucion.append("Filtrar ver documentos ");
			System.out.println("Filtrar ver documentos");
			getFoto(driver);
			Thread.sleep(25000);
			driver.switchTo().frame("gxp0_ifrm");
			boolean mensajeError = isElementPresent(By.xpath("//span/span"));
			if(mensajeError==true) {
				logEjecucion.append("No es posible consultar los documentos ");
				System.err.println("No es posible consultar los documentos");
				getFoto(driver);
				Thread.sleep(1000);
				AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
				zip.comprimir();
				Thread.sleep(5000);
				mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			} else {
				logEjecucion.append("Se visualizan los documentos ");
				System.err.println("Se visualizan los documentos");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.switchTo().defaultContent();
			Thread.sleep(1000);
			driver.findElement(By.id("gxp0_cls")).click();
			logEjecucion.append("Cerrar ventana ");
			System.out.println("Cerrar ventana");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("EXPORT")).click();
			logEjecucion.append("Descargar archivo ");
			System.out.println("Descargar archivo");
			getFoto(driver);
			Thread.sleep(60000);
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}