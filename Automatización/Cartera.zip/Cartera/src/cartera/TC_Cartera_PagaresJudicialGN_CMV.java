package cartera;

import org.testng.annotations.*;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_PagaresJudicialGN_CMV {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PagareJudicialGNCMV";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PagareJudicialGNCMV.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void testTC_Cartera_PagaresJudicialGN_CMV() throws Exception {
		try {
			credenciales.generar();
			Robot robot = new Robot();
			driver.get(credenciales.getBaseURL());
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[16]/a/span")).click();
			Thread.sleep(1000);
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			logEjecucion.append("Ingreso al m�dulo Procesos ");
			System.out.println("Ingreso al m�dulo Procesos ");
			driver.findElement(By.xpath("//div[17]/a[2]")).click();
			getFoto(driver);
			logEjecucion.append("Ingreso al subm�dulo Trabajar con remesas ");
			System.out.println("Ingreso al subm�dulo Trabajar con remesas ");
			Thread.sleep(10000);
			driver.findElement(By.id("DVELOP_BOOTSTRAP_CONFIRMPANEL1Container_DismissButton")).click();
			logEjecucion.append("Opci�n No ");
			System.out.println("Opci�n No");
			getFoto(driver);
			Thread.sleep(6000);
			new Select(driver.findElement(By.id("vCREPOLITICAJSELECCION"))).selectByVisibleText("(Todas)");
			logEjecucion.append("Filtrar por Todas ");
			System.out.println("Filtrar por Todas");
			getFoto(driver);
			Thread.sleep(15000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado Pago");
			logEjecucion.append("Filtrar por Estado Pago ");
			System.out.println("Filtrar por Estado Pago");
			getFoto(driver);
			Thread.sleep(15000);
			new Select(driver.findElement(By.id("vCREESTADOPAGO1"))).selectByVisibleText("MOROSO");
			logEjecucion.append("Opcion Moroso ");
			System.out.println("Opcion Moroso");
			getFoto(driver);
			Thread.sleep(15000);
			driver.findElement(By.xpath("//td[4]/span/a")).click();
			logEjecucion.append("Seleccionar OP ");
			System.out.println("Seleccionar OP");
			getFoto(driver);
			Thread.sleep(20000);
			String parentHandle = driver.getWindowHandle(); // get the current window handle
		    System.out.println(parentHandle);             //Prints the parent window handle
			getFoto(driver);
			Thread.sleep(1000);
		    for (String winHandle : driver.getWindowHandles()) { //Gets the new window handle
		        System.out.println(winHandle);
		        driver.switchTo().window(winHandle);
				getFoto(driver);
				Thread.sleep(1000);
		    }
			driver.findElement(By.id("W0052W0037BTNPASARAJUDICIAL")).click();
			logEjecucion.append("Cambiar a estado Judicial ");
			System.out.println("Cambiar a estado Judicial");
			getFoto(driver);
			Thread.sleep(15000);
			try {
				assertEquals(driver.findElement(By.id("span_CREESTADOPAGO")).getText(), "JUDICIAL");
				logEjecucion.append("Mensaje: " + driver.findElement(By.id("span_CREESTADOPAGO")).getText() + " ");
				System.out.println("Mensaje: " + driver.findElement(By.id("span_CREESTADOPAGO")).getText());
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append("Mensaje no encontrado: " + verificationErrors.append(e.toString()) + " ");
				System.out.println("Mensaje no encontrado: " + verificationErrors.append(e.toString()));
				getFoto(driver);
				Thread.sleep(1000);
			}
		    driver.close();
		    driver.switchTo().window(parentHandle);
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vCREESTADOPAGO1"))).selectByVisibleText("VENCIDO");
			logEjecucion.append("Opcion Moroso ");
			System.out.println("Opcion Moroso");
			getFoto(driver);
			Thread.sleep(15000);
			driver.findElement(By.xpath("//td[4]/span/a")).click();
			logEjecucion.append("Seleccionar OP ");
			System.out.println("Seleccionar OP");
			getFoto(driver);
			Thread.sleep(20000);
			String parentHandle2 = driver.getWindowHandle(); // get the current window handle
		    System.out.println(parentHandle2);             //Prints the parent window handle
			getFoto(driver);
			Thread.sleep(1000);
		    for (String winHandle : driver.getWindowHandles()) { //Gets the new window handle
		        System.out.println(winHandle);
		        driver.switchTo().window(winHandle);
				getFoto(driver);
				Thread.sleep(1000);
		    }
			driver.findElement(By.id("W0052W0037BTNPASARAJUDICIAL")).click();
			logEjecucion.append("Cambiar a estado Judicial ");
			System.out.println("Cambiar a estado Judicial");
			getFoto(driver);
			Thread.sleep(15000);
			try {
				assertEquals(driver.findElement(By.id("span_CREESTADOPAGO")).getText(), "JUDICIAL");
				logEjecucion.append("Mensaje: " + driver.findElement(By.id("span_CREESTADOPAGO")).getText() + " ");
				System.out.println("Mensaje: " + driver.findElement(By.id("span_CREESTADOPAGO")).getText());
				getFoto(driver);
				Thread.sleep(1000);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append("Mensaje no encontrado: " + verificationErrors.append(e.toString()) + " ");
				System.out.println("Mensaje no encontrado: " + verificationErrors.append(e.toString()));
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}