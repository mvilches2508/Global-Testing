package cartera;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Creditos_SeguimientoLeasing {

	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/CreditosSeguimientoLeasing";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/CreditosSeguimientoLeasing.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();
	Mantis mantis = new Mantis();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
	}

	@Test
	public void testTCCarteraCreditosSeguimientoLeasing() throws Exception {
		try {
			driver.get(credenciales.getBaseURL());
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			System.out.println("Se ingresa a la p�g: " + credenciales.getBaseURL() + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			logEjecucion.append("Inicio de sesi�n ");
			System.out.println("Inicio de sesi�n");
			Thread.sleep(10000);
			getFoto(driver);
			driver.findElement(By.xpath("//span/a")).click();
			Thread.sleep(10000);
			boolean simbolo = isElementPresent(By.id("ADDDYNAMICFILTERS1"));
			if (simbolo == true) {
				System.out.println("Accede al men� Cr�ditos");
				logEjecucion.append("Accede al men� Cr�ditos ");
			} else {
				System.out.println("No accede al men� Cr�ditos");
				logEjecucion.append("No accede al men� Cr�ditos");
			}
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("ADDDYNAMICFILTERS1")).click();
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Tipo Cr�dito");
			System.out.println("Selecci�n de filtro tipo cr�dito");
			logEjecucion.append("Selecci�n de filtro tipo cr�dito ");
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vSOLICITUDTIPOCREDITO1"))).selectByValue("3");
			System.out.println("Selecci�n de opci�n Leasing");
			logEjecucion.append("Selecci�n de opci�n Leasing ");
			getFoto(driver);
			Thread.sleep(90000);
			new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR2"))).selectByVisibleText("Estado Pago");
			System.out.println("Selecci�n de opci�n estado pago");
			logEjecucion.append("Selecci�n de opci�n estado pago ");
			getFoto(driver);
			Thread.sleep(150000);
			new Select(driver.findElement(By.id("vCREESTADOPAGO2"))).selectByVisibleText("VENCIDO");
			System.out.println("Selecci�n de opci�n vencido");
			logEjecucion.append("Selecci�n de opci�n vencido ");
			getFoto(driver);
			Thread.sleep(150000);
			boolean boton = isElementPresent(By.id("vINFOCLIENTE1_0001"));
			if (boton == true) {
				driver.findElement(By.id("vINFOCLIENTE1_0001")).click();
				System.out.println("Apertura de ventana para registrar seguimiento");
				logEjecucion.append("Apertura de ventana para registrar seguimiento ");
				getFoto(driver);
				Thread.sleep(20000);
			} else {
				System.out.println("Error al acceder a ventana de registro de seguimiento");
				logEjecucion.append("Error al acceder a ventana de registro de seguimiento ");
				getFoto(driver);
			}
			driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
			boolean registrarSeguimiento = isElementPresent(By.xpath("//*[@id=\"vIMGCLIENTE\"]"));
			if (registrarSeguimiento == true) {
				driver.findElement(By.id("REGISTRARSEGUIMIENTO")).click();
				logEjecucion.append("Se procede a ingresar seguimiento ");
				System.out.println("Se procede a ingresar seguimiento");
				getFoto(driver);
				Thread.sleep(30000);
				driver.switchTo().defaultContent();
			} else {
				logEjecucion.append("Error al registrar seguimiento ");
				System.out.println("Error al registrar seguimiento");
				getFoto(driver);
			}
			driver.switchTo().frame(driver.findElement(By.id("gxp1_ifrm")));
			new Select(driver.findElement(By.id("vTIPOGESTIONID"))).selectByVisibleText("Carta");
			logEjecucion.append("Tipo gestion: Carta ");
			System.out.println("Tipo gestion: Carta");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vTIPOCONTACTOID"))).selectByVisibleText("Sin Contacto");
			logEjecucion.append("Tipo contacto: Sin contacto ");
			System.out.println("Tipo contacto: Sin contacto");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vCAUSALNOPAGOID"))).selectByVisibleText("No contesta");
			logEjecucion.append("Causal no pago: No contesta ");
			System.out.println("Causal no pago: No contesta");
			getFoto(driver);
			Thread.sleep(1000);
			new Select(driver.findElement(By.id("vESTADOSEGUIMIENTOID"))).selectByVisibleText("Volver a Llamar");
			logEjecucion.append("Estado seguimiento: Volver a llamar ");
			System.out.println("Estado seguimiento: Volver a llamar");
			getFoto(driver);
			Thread.sleep(1000);
			SimpleDateFormat dia = new SimpleDateFormat("dd");
			SimpleDateFormat mes = new SimpleDateFormat("MM");
			SimpleDateFormat anno = new SimpleDateFormat("yy");
			String diaActual = dia.format(new Date());
			String mesActual = mes.format(new Date());
			String annoActual = anno.format(new Date());
			int diaHoy = Integer.parseInt(diaActual);
			int mesHoy = Integer.parseInt(mesActual);
			int annoHoy = Integer.parseInt(annoActual);
			System.out.println("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy);
			logEjecucion.append("Se ingresa fecha: " + diaHoy + "/" + mesHoy + "/" + annoHoy + " ");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vSEGCREDITOPROXIMAFECHA').value=" + diaHoy + "+'/'+" + mesActual+ "+'/'+" + annoActual + ";");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("vSEGCREDITOCOMENTARIO")).clear();
			driver.findElement(By.id("vSEGCREDITOCOMENTARIO")).sendKeys("Seguimiento Leasing");
			logEjecucion.append("Comentario ingresado: Seguimiento Leasing ");
			System.out.println("Comentario ingresado: Seguimiento Leasing");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
			logEjecucion.append("Se confirma registro de seguimiento ");
			System.out.println("Se confirma registro de seguimiento");
			getFoto(driver);
			Thread.sleep(20000);
			driver.switchTo().defaultContent();
			try {
				assertEquals(driver.getTitle(), "Cr�ditos");
				System.out.println("Registro de seguimiento de manera exitosa");
				logEjecucion.append("Registro de seguimiento de manera exitosa ");
				getFoto(driver);
			} catch (Error e) {
				verificationErrors.append(e.toString());
				logEjecucion.append(verificationErrors.append(e.toString()) + " ");
				System.out.println(verificationErrors.append(e.toString()));
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
			getFoto(driver);
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}