package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.fail;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_ProcesoRemesa_DepositarRemesa {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	Credenciales credenciales = new Credenciales();
	Mantis mantis = new Mantis();
	private static final String EVIDENCIA = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PRDepositarReporte";
	private static final String EVIDENCIAZIP = "C:/Program Files (x86)/Jenkins/workspace/Global_Cartera/bin/cartera/evidencia/PRDepositarReporte.zip";
	private StringBuilder logEjecucion = new StringBuilder();
	String className = this.getClass().getSimpleName();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "bin/cartera/driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		options.addArguments("window-size=1366x768");
		driver = new ChromeDriver(options);
		baseUrl = "http://54.235.81.157/carteragx16/seclogin.aspx";
	}

	@Test
	public void testTCCarteraProcesoRemesaDepositarRemesa() throws Exception {
		try {
			Robot robot = new Robot();
			driver.get(baseUrl);
			credenciales.generar();
			Thread.sleep(8000);
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Se ingresa a la p�gina: " + baseUrl + " ");
			System.out.println("Se ingresa a la p�gina: " + baseUrl + " ");
			driver.findElement(By.id("vUSUARIONOMBRE")).clear();
			driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys(credenciales.getUser());
			Thread.sleep(1000);
			driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
			driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys(credenciales.getPass());
			logEjecucion.append("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " "+ credenciales.getPass() + " ");
			System.out.println("Se ingresa las siguientes credenciales: " + credenciales.getUser() + " " + credenciales.getPass());
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.name("BTNENTER")).click();
			getFoto(driver);
			Thread.sleep(10000);
			driver.findElement(By.xpath("//li[10]/a/span")).click();
			robot.mousePress(InputEvent.BUTTON1_MASK);
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
			logEjecucion.append("Ingreso al m�dulo Procesos ");
			System.out.println("Ingreso al m�dulo Procesos ");
			getFoto(driver);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//div[11]/a[8]")).click();
			getFoto(driver);
			Thread.sleep(1000);
			logEjecucion.append("Ingreso al subm�dulo Trabajar con remesas ");
			System.out.println("Ingreso al subm�dulo Trabajar con remesas ");
			getFoto(driver);
			Thread.sleep(5000);
			boolean depositar = isElementPresent(By.id("vIMGDEPOSITAREMESA_0001"));
			if (depositar == true) {
				driver.findElement(By.id("vIMGDEPOSITAREMESA_0001")).click();
				logEjecucion.append("Se procede a depositar remesa ");
				System.out.println("Se procede a depositar remesa ");
				getFoto(driver);
				Thread.sleep(5000);
				driver.findElement(By.id("DVELOP_CONFIRMPANEL_IMGDEPOSITAREMESAContainer_SaveButton")).click();
				logEjecucion.append("Confirma deposito remesa ");
				System.out.println("Confirma deposito remesa ");
				getFoto(driver);
				Thread.sleep(5000);
				driver.switchTo().frame("gxp0_ifrm");
				logEjecucion.append("Acceso al iframe gxp0_ifrm ");
				System.out.println("Acceso al iframe gxp0_ifrm ");
				Thread.sleep(1000);
				new Select(driver.findElement(By.id("vCUENTACORRIENTEID"))).selectByVisibleText("Banco Corpbanca - 33638270");
				logEjecucion.append("Selecciona cuenta corriente Banco Corpbanca - 33638270 ");
				System.out.println("Selecciona cuenta corriente Banco Corpbanca - 33638270 ");
				getFoto(driver);
				Thread.sleep(1000);
				driver.findElement(By.name("BTNENTER")).click();
				logEjecucion.append("Confirmar ");
				System.out.println("Confirmar ");
				getFoto(driver);
				driver.switchTo().defaultContent();
				Thread.sleep(10000);
				driver.findElement(By.xpath("//td[4]/span/a")).click();
				logEjecucion.append("Hacer clic en enlace ID ");
				System.out.println("Hacer clic en enlace ID ");
				getFoto(driver);
				Thread.sleep(10000);
				driver.findElement(By.xpath("//td[2]/table/tbody/tr/td/span/a")).click();
				logEjecucion.append("Secci�n remesa ");
				System.out.println("Secci�n remesa ");
				getFoto(driver);
				Thread.sleep(10000);
				driver.findElement(By.id("W0016W0037EXPORT")).click();
				logEjecucion.append("Descarga archivo excel ");
				System.out.println("Descarga archivo excel ");
				getFoto(driver);
				Thread.sleep(5000);
				robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
				getFoto(driver);
				Thread.sleep(1000);
			} else {
				System.out.println("No hay remesas para depositar ");
				logEjecucion.append("No hay remesas para depositar ");
				getFoto(driver);
				Thread.sleep(1000);
			}
			driver.findElement(By.id("IMAGE2_MPAGE")).click();
		} catch (Exception e) {
			logEjecucion.append("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			System.err.println("No es posible interactuar con los elementos de la p�gina, se sugiere consultar la evidencia para m�s detalle");
			getFoto(driver);
			Thread.sleep(1000);
			AppZip zip = new AppZip(EVIDENCIAZIP, EVIDENCIA);
			zip.comprimir();
			Thread.sleep(5000);
			mantis.creaIssue(EVIDENCIAZIP, logEjecucion.toString(), className);
			throw (e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		getFoto(driver);
		Thread.sleep(1000);
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private void getFoto(WebDriver webDriver) {
		try {
			File path = new File(EVIDENCIA);
			path.mkdirs();
			Date d = new Date();
			SimpleDateFormat sd = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_a");
			String timestamp = sd.format(d);
			String imgname = path + "\\" + timestamp + ".png";
			File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(imgname));
		} catch (IOException ex) {
			System.out.println("Error al capturar secuencia: " + ex);
		}
	}
}