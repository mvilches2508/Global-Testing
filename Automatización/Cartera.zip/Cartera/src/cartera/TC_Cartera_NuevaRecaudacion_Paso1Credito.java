package cartera;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.testng.annotations.*;
import static org.testng.Assert.fail;
import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_NuevaRecaudacion_Paso1Credito {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraNuevaRecaudacionPaso1Credito() throws Exception {
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		driver.get(baseUrl);
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys("mvalles");
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys("Mvll18.");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[2]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(8000);
		new Select(driver.findElement(By.id("vCREESTADOCONTRATO"))).selectByVisibleText("VIGENTE");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNBUSCAR")).click();
		Thread.sleep(10000);
		driver.findElement(By.id("vSELECCIONAR_0002")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0001")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("vGRIDCUOTASSELECTED_0002")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("BTNSIGUIENTE")).click();
		Thread.sleep(10000);
		driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
		boolean ingresarFecha = isElementPresent(By.id("vCREFCHPAGOREAL"));
		if (ingresarFecha == true) {
			Date fecha = new Date();
			DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy");
			driver.findElement(By.id("vCREFCHPAGOREAL")).clear();
			driver.findElement(By.id("vCREFCHPAGOREAL")).sendKeys(formatoFecha.format(fecha));
		} else {
			System.out.println("Error al ingresar fecha");
		}		
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		driver.switchTo().defaultContent();
		Thread.sleep(8000);
		boolean paso = isElementPresent(By.id("TEXTBLOCKTITLE"));
		if (paso == true) {
			System.out.println("Paso creado de manera existosa");
		} else {
			System.out.println("Error al procesar");
		}
		Thread.sleep(3000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}

}