package cartera;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TC_Cartera_NuevaRecaudacion_Paso1Credito {

	
	public static void main(String[] args) {
		Date fecha = new Date();
		  DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy");
		  System.out.println(formatoFecha.format(fecha));
	}

}
