package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Cheques_VolverDepositado {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraChequesVolverDepositado() throws Exception {
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		driver.get(baseUrl);
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys("mvalles");
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys("Mvll18.");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[6]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCHEQUEESTADO1"))).selectByVisibleText("COBRADO");
		Thread.sleep(10000);
		String procesarCheque = driver.findElement(By.xpath("//tr[2]/td[8]/span/a")).getText();
		System.out.println(procesarCheque);
		driver.findElement(By.id("vCAMBIARESTADOADEPOSITADO_0002")).click();
		Thread.sleep(10000);
		boolean depositarCheque = isElementPresent(By.xpath("//td"));
		if (depositarCheque == true) {
			Date fecha = new Date();
			DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy");
			driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
			driver.findElement(By.id("vCHEQUEFECHADEPOSITO")).clear();
			driver.findElement(By.id("vCHEQUEFECHADEPOSITO")).sendKeys(formatoFecha.format(fecha));
			Thread.sleep(1000);
			driver.findElement(By.id("vCHEQUENROCOMPROBANTE")).clear();
			driver.findElement(By.id("vCHEQUENROCOMPROBANTE")).sendKeys("01020340");
			Thread.sleep(1000);
			driver.findElement(By.id("BTNENTER")).click();
		} else {
			System.out.println("Error a volver depositar cheque");
		}
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("N� Cheque");
		Thread.sleep(10000);
		driver.findElement(By.id("vCHEQUENUMERO1")).clear();
		driver.findElement(By.id("vCHEQUENUMERO1")).sendKeys(procesarCheque);
		Thread.sleep(1000);
		driver.findElement(By.id("vCHEQUENUMERO1")).click();
		Thread.sleep(1000);
		try {
			assertEquals(driver.findElement(By.id("span_CHEQUEESTADO_0001")).getText(), "DEPOSITADO");
			System.out.println("Cheque en estado cobrado es nuevamente depositado de manera exitosa");
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		Thread.sleep(1000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}