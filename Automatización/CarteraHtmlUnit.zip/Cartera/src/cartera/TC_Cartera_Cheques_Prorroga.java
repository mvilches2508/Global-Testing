package cartera;

import org.testng.annotations.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

public class TC_Cartera_Cheques_Prorroga {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://54.235.81.157/carteragx15/seclogin.aspx";
	}

	@Test
	public void testTCCarteraChequesProrroga() throws Exception {
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		driver.get(baseUrl);
		Thread.sleep(8000);
		driver.findElement(By.id("vUSUARIONOMBRE")).clear();
		driver.findElement(By.id("vUSUARIONOMBRE")).sendKeys("mvalles");
		Thread.sleep(1000);
		driver.findElement(By.id("vUSUARIOPASSWORD")).clear();
		driver.findElement(By.id("vUSUARIOPASSWORD")).sendKeys("Mvll18.");
		Thread.sleep(1000);
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//tr[6]/td/table/tbody/tr/td[2]/p/span/a")).click();
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vDYNAMICFILTERSSELECTOR1"))).selectByVisibleText("Estado");
		Thread.sleep(10000);
		new Select(driver.findElement(By.id("vCHEQUEESTADO1"))).selectByVisibleText("EN CARTERA");
		Thread.sleep(10000);
		driver.findElement(By.id("vPRORROGA_0010")).click();
		Thread.sleep(10000);
		driver.switchTo().frame(driver.findElement(By.id("gxp0_ifrm")));
		boolean campoFecha = isElementPresent(By.id("vFECHA"));
		if (campoFecha == true) {
			SimpleDateFormat fecha = new SimpleDateFormat("ddMMyy");
			String fechaHoy = fecha.format(new Date());
			int dia = Integer.parseInt(fechaHoy);
			System.out.println(dia);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('vCREFCHPAGOREAL').value="+dia+";");
			Thread.sleep(1000);
		} else {
			System.out.println("No reconoce el campo fecha");
		}
		driver.findElement(By.id("BTNENTER")).click();
		Thread.sleep(5000);
		String mensaje = driver.findElement(By.xpath("//span/div")).getText();
		try {
			assertEquals(driver.findElement(By.xpath("//span/div")).getText(),
					"La fecha de vto. ingresada supera el m�ximo de d�as de prorroga (d�as solicitados: 149).");
			System.out.println("Verificaci�n exitosa: " + mensaje);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		Thread.sleep(2000);
		driver.findElement(By.id("BTN_CANCEL")).click();
		driver.switchTo().defaultContent();
		Thread.sleep(8000);
		driver.findElement(By.id("IMAGE2_MPAGE")).click();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}